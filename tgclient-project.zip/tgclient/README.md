# TgClient — Fase 1: Setup Project + Multi Akun + Login

Skeleton project Android (Kotlin) untuk klien Telegram sederhana. Fase ini
mencakup bagian pertama dari rencana: setup project, `AccountManager`
(fondasi multi akun), dan layar login (OTP + 2FA) untuk satu akun.
Chat list, kirim pesan, profil lengkap, dan report menyusul di fase
berikutnya di atas fondasi ini.

## Yang sudah ada
- `tdlib/AccountStore.kt` — persist daftar akun (SharedPreferences)
- `tdlib/TdlibSession.kt` — wrapper 1 instance TDLib (auth state, profil, kirim pesan generik via `send()`)
- `tdlib/AccountManager.kt` — kelola banyak `TdlibSession` sekaligus (fondasi multi akun)
- `login/LoginActivity.kt` — UI login: nomor HP → OTP → (opsional) password 2FA
- `MainActivity.kt` — placeholder setelah login sukses, menampilkan profil dasar

## PENTING — hal yang WAJIB kamu lakukan sebelum project ini bisa di-build

Saya menulis semua kode di atas mengikuti API resmi TDLib
(`org.drinkless.tdlib.Client` / `TdApi`) berdasarkan pengetahuan saya —
**tapi saya tidak punya akses Android SDK maupun internet di lingkungan
ini**, jadi saya tidak bisa benar-benar meng-compile atau menjalankan
project ini untuk memverifikasinya. Ada 2 hal yang murni tidak bisa saya
sediakan dan harus kamu lakukan sendiri di Android Studio:

### 1. Binary TDLib
TDLib tidak tersedia di Maven Central. Pilih salah satu:

**Opsi A — build dari source (paling aman & terpercaya)**
1. Clone https://github.com/tdlib/td
2. Ikuti panduan build Android resminya (butuh Android NDK + CMake) — ada di `example/android/` pada repo tersebut
3. Hasil build berupa file `.so` per ABI + source Java (`org.drinkless.tdlib.*`) — taruh `.so` di `app/src/main/jniLibs/<abi>/` dan source Java di `app/src/main/java/`

**Opsi B — pakai AAR prebuilt dari sumber yang kamu percaya**
- Taruh file `.aar` di `app/libs/tdlib.aar`
- Uncomment baris `implementation(name = "tdlib", ext = "aar")` di `app/build.gradle.kts`
- ⚠️ Hati-hati: hanya pakai AAR dari sumber yang benar-benar kamu percaya, karena ini adalah kode native yang punya akses penuh ke koneksi & data akun Telegram penggunanya.

### 2. API ID & API Hash
1. Buka https://my.telegram.org → login pakai akun Telegram kamu
2. Masuk ke "API development tools", buat aplikasi baru (gratis)
3. Isi `API_ID` dan `API_HASH` di `app/src/main/java/com/tgclient/app/tdlib/TdlibConfig.kt`

### 3. Cocokkan versi API jika perlu
TDLib kadang mengubah nama field kecil antar versi (mis. `usernames.editableUsername`
vs field `username` lama). Kode di sini ditulis mengikuti struktur TDLib versi
terbaru yang saya ketahui — kalau versi TDLib yang kamu build berbeda dan
Android Studio menandai error tipe/field yang tidak cocok, sesuaikan nama
field tersebut mengikuti `TdApi.java`/`.kt` hasil build kamu sendiri
(Android Studio akan menunjukkan persis baris mana yang perlu diubah).

## Setelah 1 & 2 di atas selesai
1. Buka folder ini di Android Studio (Giraffe/Koala ke atas)
2. Sync Gradle
3. Run ke device/emulator — layar login akan muncul duluan

## Fase berikutnya (belum dikerjakan)
- Daftar dialog/chat (`ChatListFragment`)
- Buka chat & kirim/terima pesan real-time (`ChatActivity`)
- UI switcher multi akun
- Layar profil lengkap
- Fitur report (`ReportDialog`, pakai `TdApi.ReportChat`)
