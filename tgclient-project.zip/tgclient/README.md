# TgClient — Fase 1-5: Setup, Login, Chat List, Kirim Pesan, Multi Akun, Profil, Report

Skeleton project Android (Kotlin) untuk klien Telegram sederhana, gaya
Nekogram. Login + multi akun + daftar chat + kirim/terima pesan real-time +
switcher akun + profil + report standar (satu laporan per akun, bukan
batch) sudah ada di atas fondasi TDLib yang sama.

## Yang sudah ada
- `tdlib/AccountStore.kt` — persist daftar akun (SharedPreferences)
- `tdlib/TdlibSession.kt` — wrapper 1 instance TDLib (auth state, profil, generic `send()`)
- `tdlib/AccountManager.kt` — kelola banyak `TdlibSession` sekaligus (multi akun)
- `login/LoginActivity.kt` — UI login: nomor HP → OTP → (opsional) password 2FA; bisa dipaksa nambah akun baru lewat `EXTRA_FORCE_NEW_ACCOUNT`
- `MainActivity.kt` — daftar chat akun aktif (real-time via `ChatListRepository`), menu Ganti Akun & Profil Saya
- `account/AccountSwitcherDialog.kt` — bottom sheet pilih akun aktif / tambah akun baru
- `chat/ChatActivity.kt` + `tdlib/ChatRepository.kt` — buka 1 chat, load riwayat, terima pesan baru real-time, kirim pesan teks
- `profile/ProfileActivity.kt` — profil sendiri (live) atau profil user lain (sekali-fetch) dengan tombol Laporkan
- `report/ReportDialog.kt` — dialog report standar (`TdApi.ReportChat`), satu laporan per akun aktif — bukan alat mass-report

## PENTING — hal yang WAJIB kamu lakukan sebelum project ini bisa di-build

Saya menulis semua kode di atas mengikuti API resmi TDLib
(`org.drinkless.tdlib.Client` / `TdApi`) berdasarkan pengetahuan saya —
**tapi saya tidak punya akses Android SDK maupun internet di lingkungan
ini**, jadi saya tidak bisa benar-benar meng-compile atau menjalankan
project ini untuk memverifikasinya. Ada 2 hal yang murni tidak bisa saya
sediakan dan harus kamu lakukan sendiri di Android Studio:

### 1. Binary TDLib
TDLib tidak tersedia di Maven Central. Pilih salah satu:

**Opsi A — build dari source (paling aman & terpercaya)**
1. Clone https://github.com/tdlib/td
2. Ikuti panduan build Android resminya (butuh Android NDK + CMake) — ada di `example/android/` pada repo tersebut
3. Hasil build berupa file `.so` per ABI + source Java (`org.drinkless.tdlib.*`) — taruh `.so` di `app/src/main/jniLibs/<abi>/` dan source Java di `app/src/main/java/`

**Opsi B — pakai AAR prebuilt dari sumber yang kamu percaya**
- Taruh file `.aar` di `app/libs/tdlib.aar`
- Uncomment baris `implementation(name = "tdlib", ext = "aar")` di `app/build.gradle.kts`
- ⚠️ Hati-hati: hanya pakai AAR dari sumber yang benar-benar kamu percaya, karena ini adalah kode native yang punya akses penuh ke koneksi & data akun Telegram penggunanya.

### 2. API ID & API Hash
1. Buka https://my.telegram.org → login pakai akun Telegram kamu
2. Masuk ke "API development tools", buat aplikasi baru (gratis)
3. Isi `API_ID` dan `API_HASH` di `app/src/main/java/com/tgclient/app/tdlib/TdlibConfig.kt`

### 3. Cocokkan versi API jika perlu
TDLib kadang mengubah nama field kecil antar versi (mis. `usernames.editableUsername`
vs field `username` lama). Kode di sini ditulis mengikuti struktur TDLib versi
terbaru yang saya ketahui — kalau versi TDLib yang kamu build berbeda dan
Android Studio menandai error tipe/field yang tidak cocok, sesuaikan nama
field tersebut mengikuti `TdApi.java`/`.kt` hasil build kamu sendiri
(Android Studio akan menunjukkan persis baris mana yang perlu diubah).

## Setelah 1 & 2 di atas selesai
1. Buka folder ini di Android Studio (Giraffe/Koala ke atas)
2. Sync Gradle
3. Run ke device/emulator — layar login akan muncul duluan

## Belum dikerjakan / ide lanjutan
- Kirim media (foto, video, dokumen, stiker) — saat ini isi non-teks cuma ditampilkan sebagai label ("📷 Foto", dst), belum bisa dikirim dari app
- Notifikasi push (perlu WorkManager/Firebase + TDLib background handling)
- Pagination saat scroll ke atas di `ChatActivity` (saat ini cuma load 50 pesan terakhir sekali)
- Pull-to-refresh & swipe actions di daftar chat
- Report pesan spesifik lewat long-press di `ChatActivity` (constructor `ReportDialog` sudah menerima `messageIds`, tinggal dipanggil dari listener long-click)

## Catatan versi TDLib (masih berlaku dari Fase 1)
Field/parameter TDLib (`ReportChat`, `SendMessage`, `InputMessageText`, dll.)
kadang berubah nama/urutan antar versi. Kode di sini ditulis mengikuti
struktur TDLib yang saya ketahui, tapi karena saya tidak punya Android SDK
di sini, saya tidak bisa benar-benar meng-compile untuk memastikan cocok
persis dengan versi binary yang kamu pakai (termasuk dari link TDLib
prebuilt yang kamu kasih). Kalau Android Studio menandai mismatch tipe/nama
field, sesuaikan mengikuti `TdApi.java`/`.kt` hasil build kamu sendiri.
