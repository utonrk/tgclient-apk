package com.tgclient.app.login

/**
 * Minimal sanity checks for a phone number before it's sent to TDLib.
 * TDLib itself is the real source of truth (it'll reject genuinely invalid
 * numbers) — this is just enough to catch obvious typos client-side, e.g.
 * an empty field, letters, or a number way too short/long to be real.
 */
object PhoneNumberValidator {

    private const val MIN_NATIONAL_DIGITS = 5
    private const val MAX_TOTAL_DIGITS = 15 // E.164 hard limit, dial code + national number

    /** Strips everything but digits, and a single leading "0" trunk prefix (e.g. "081234" -> "81234"). */
    fun sanitizeNationalNumber(raw: String): String {
        val digitsOnly = raw.filter { it.isDigit() }
        return digitsOnly.removePrefix("0")
    }

    sealed class Result {
        data object Valid : Result()
        data object Empty : Result()
        data object TooShort : Result()
        data object TooLong : Result()
    }

    fun validate(dialCode: String, nationalNumber: String): Result {
        if (nationalNumber.isEmpty()) return Result.Empty
        if (nationalNumber.length < MIN_NATIONAL_DIGITS) return Result.TooShort
        if (dialCode.length + nationalNumber.length > MAX_TOTAL_DIGITS) return Result.TooLong
        return Result.Valid
    }
}
