package com.tgclient.app.account

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.tgclient.app.R
import com.tgclient.app.login.LoginActivity
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession

/**
 * Lets the user pick which logged-in account is active, or start the login
 * flow again to add a new one. [onAccountChanged] is called after the user
 * taps a *different* account so the caller (chat list) can refresh itself.
 */
class AccountSwitcherDialog(
    private val activity: android.app.Activity,
    private val onAccountChanged: () -> Unit,
) {

    fun show() {
        val dialog = BottomSheetDialog(activity)
        val view = LayoutInflater.from(activity)
            .inflate(R.layout.dialog_account_switcher, null, false)
        dialog.setContentView(view)

        val recycler = view.findViewById<RecyclerView>(R.id.accountsRecycler)
        val addRow = view.findViewById<TextView>(R.id.addAccountRow)

        val sessions = AccountManager.listSessionsInOrder()
        val activeId = AccountManager.getActiveAccountId()

        recycler.layoutManager = LinearLayoutManager(activity)
        recycler.adapter = Adapter(sessions, activeId) { session ->
            dialog.dismiss()
            if (session.accountId != activeId) {
                AccountManager.setActiveAccountId(session.accountId)
                onAccountChanged()
            }
        }

        addRow.setOnClickListener {
            dialog.dismiss()
            val intent = Intent(activity, LoginActivity::class.java)
                .putExtra(LoginActivity.EXTRA_FORCE_NEW_ACCOUNT, true)
            activity.startActivity(intent)
        }

        dialog.show()
    }

    private class Adapter(
        private val sessions: List<TdlibSession>,
        private val activeAccountId: String?,
        private val onClick: (TdlibSession) -> Unit,
    ) : RecyclerView.Adapter<Adapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val name: TextView = view.findViewById(R.id.accountName)
            val phone: TextView = view.findViewById(R.id.accountPhone)
            val activeLabel: TextView = view.findViewById(R.id.accountActiveLabel)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_account, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val session = sessions[position]
            val profile = session.profile.value
            val fullName = "${profile.firstName} ${profile.lastName}".trim()
            holder.name.text = fullName.ifBlank { "(Belum ada nama)" }
            holder.phone.text = if (profile.phoneNumber.isNotBlank()) "+${profile.phoneNumber}" else ""
            holder.activeLabel.visibility =
                if (session.accountId == activeAccountId) View.VISIBLE else View.GONE
            holder.itemView.setOnClickListener { onClick(session) }
        }

        override fun getItemCount(): Int = sessions.size
    }
}
