package com.tgclient.app.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.tgclient.app.R
import com.tgclient.app.report.ReportDialog
import com.tgclient.app.tdlib.TdlibSession

/**
 * The row of icon actions that appears on long-press of a message bubble
 * (Copy / Forward / Report), mirroring the standard Telegram-client
 * long-press menu. Kept intentionally small: this is not a full
 * multi-select action bar, just the 3 single-message actions requested.
 */
object MessageActionsDialog {

    fun show(
        context: Context,
        session: TdlibSession,
        chatId: Long,
        messageId: Long,
        messageText: String,
    ) {
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(24, 32, 24, 16)
        }

        val dialog = AlertDialog.Builder(context)
            .setView(row)
            .create()

        row.addView(
            actionView(context, android.R.drawable.ic_menu_edit, context.getString(R.string.action_copy)) {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("message", messageText))
                Toast.makeText(context, context.getString(R.string.status_copied), Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            },
        )

        row.addView(
            actionView(context, android.R.drawable.ic_menu_send, context.getString(R.string.action_forward)) {
                dialog.dismiss()
                ForwardChatPickerDialog(context, session, chatId, messageId).show()
            },
        )

        row.addView(
            actionView(context, android.R.drawable.ic_dialog_alert, context.getString(R.string.action_report_chat)) {
                dialog.dismiss()
                ReportDialog(context, session, chatId, longArrayOf(messageId)).show()
            },
        )

        dialog.show()
    }

    private fun actionView(context: Context, iconRes: Int, label: String, onClick: () -> Unit): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 8, 28, 8)
            isClickable = true
            isFocusable = true
            val outValue = android.util.TypedValue()
            context.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, outValue, true)
            setBackgroundResource(outValue.resourceId)

            addView(
                ImageView(context).apply {
                    setImageResource(iconRes)
                    layoutParams = LinearLayout.LayoutParams(72, 72)
                },
            )
            addView(
                TextView(context).apply {
                    text = label
                    textSize = 12f
                    setTypeface(typeface, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setPadding(0, 8, 0, 0)
                },
            )
            setOnClickListener { onClick() }
        }
    }
}
