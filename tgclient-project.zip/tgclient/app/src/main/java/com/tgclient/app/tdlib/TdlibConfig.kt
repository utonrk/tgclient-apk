package com.tgclient.app.tdlib

/**
 * Fill these in with your own values from https://my.telegram.org
 * ("API development tools" section). These are free to obtain but
 * unique per developer/app — do NOT hardcode someone else's values,
 * and do NOT commit real values to a public repository.
 */
object TdlibConfig {
    const val API_ID: Int = 0 // TODO: replace with your api_id
    const val API_HASH: String = "" // TODO: replace with your api_hash
}
