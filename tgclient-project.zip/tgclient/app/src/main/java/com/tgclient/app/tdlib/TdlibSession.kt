package com.tgclient.app.tdlib

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import org.drinkless.tdlib.Client
import org.drinkless.tdlib.TdApi
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Wraps exactly one TDLib [Client] instance, i.e. exactly one Telegram
 * account. AccountManager owns one TdlibSession per logged-in (or
 * logging-in) account.
 *
 * Every account gets its own on-disk database/files directory so that
 * multiple accounts never share state.
 */
class TdlibSession(
    val accountId: String,
    private val databaseDirectory: String,
    private val filesDirectory: String,
) {

    sealed class AuthState {
        data object Uninitialized : AuthState()
        data object WaitPhoneNumber : AuthState()
        data object WaitCode : AuthState()
        data object WaitPassword : AuthState()
        data object LoggingIn : AuthState()
        data object Ready : AuthState()
        data object LoggedOut : AuthState()
        data class Error(val message: String) : AuthState()
    }

    private val _authState = MutableStateFlow<AuthState>(AuthState.Uninitialized)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    /** Basic profile info, populated once TdApi.UpdateUser / AuthorizationStateReady arrive. */
    data class Profile(
        val userId: Long = 0L,
        val firstName: String = "",
        val lastName: String = "",
        val username: String = "",
        val phoneNumber: String = "",
    )

    private val _profile = MutableStateFlow(Profile())
    val profile: StateFlow<Profile> = _profile.asStateFlow()

    /** Raw TDLib updates (new messages, chat updates, etc.) for later screens to consume. */
    private val _updates = MutableSharedFlow<TdApi.Object>(extraBufferCapacity = 64)
    val updates = _updates.asSharedFlow()

    private var myUserId: Long = 0L

    /**
     * Lives as long as this session does (not tied to any one Activity),
     * so session-wide state like [chatListRepository] survives screen
     * rotation and is shared by every screen instead of being reloaded
     * per-screen.
     */
    private val sessionScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /**
     * The account's main chat list, kept live for as long as the session
     * exists. Started lazily on first access; both the chat-list screen and
     * the forward-message picker read from this same instance instead of
     * each spinning up their own.
     */
    val chatListRepository: ChatListRepository by lazy {
        ChatListRepository(this, sessionScope).also { it.start() }
    }

    private val client: Client = Client.create(
        /* updatesHandler = */ { update -> handleUpdate(update) },
        /* updatesExceptionHandler = */ null,
        /* defaultExceptionHandler = */ null,
    )

    private fun handleUpdate(update: TdApi.Object) {
        when (update) {
            is TdApi.UpdateAuthorizationState -> handleAuthorizationState(update.authorizationState)
            is TdApi.UpdateUser -> {
                if (update.user.id == myUserId) {
                    _profile.value = Profile(
                        userId = update.user.id,
                        firstName = update.user.firstName,
                        lastName = update.user.lastName,
                        username = update.user.usernames?.editableUsername ?: "",
                        phoneNumber = update.user.phoneNumber,
                    )
                }
            }
            else -> {
                // Chat list / message updates are forwarded as-is; the
                // chat-list and chat screens (next phase) subscribe to
                // `updates` and filter for what they need.
                _updates.tryEmit(update)
            }
        }
    }

    private fun handleAuthorizationState(state: TdApi.AuthorizationState) {
        when (state) {
            is TdApi.AuthorizationStateWaitTdlibParameters -> {
                sendFireAndForget(buildTdlibParameters())
            }
            is TdApi.AuthorizationStateWaitPhoneNumber -> {
                _authState.value = AuthState.WaitPhoneNumber
            }
            is TdApi.AuthorizationStateWaitCode -> {
                _authState.value = AuthState.WaitCode
            }
            is TdApi.AuthorizationStateWaitPassword -> {
                _authState.value = AuthState.WaitPassword
            }
            is TdApi.AuthorizationStateLoggingOut -> {
                _authState.value = AuthState.LoggingIn
            }
            is TdApi.AuthorizationStateReady -> {
                _authState.value = AuthState.Ready
                fetchMyUserId()
            }
            is TdApi.AuthorizationStateClosed -> {
                _authState.value = AuthState.LoggedOut
            }
            else -> {
                // AuthorizationStateClosing, etc. — no UI-relevant change.
            }
        }
    }

    private fun buildTdlibParameters(): TdApi.SetTdlibParameters {
        return TdApi.SetTdlibParameters().apply {
            apiId = TdlibConfig.API_ID
            apiHash = TdlibConfig.API_HASH
            databaseDirectory = this@TdlibSession.databaseDirectory
            filesDirectory = this@TdlibSession.filesDirectory
            useFileDatabase = true
            useChatInfoDatabase = true
            useMessageDatabase = true
            useSecretChats = false
            systemLanguageCode = "id"
            deviceModel = "Android"
            systemVersion = "Unknown"
            applicationVersion = "0.1.0"
        }
    }

    private fun fetchMyUserId() {
        client.send(TdApi.GetMe()) { result ->
            if (result is TdApi.User) {
                myUserId = result.id
                _profile.value = Profile(
                    userId = result.id,
                    firstName = result.firstName,
                    lastName = result.lastName,
                    username = result.usernames?.editableUsername ?: "",
                    phoneNumber = result.phoneNumber,
                )
            }
        }
    }

    // ---- Public suspend API used by the login screen / later screens ----

    suspend fun submitPhoneNumber(phoneNumber: String) {
        _authState.value = AuthState.LoggingIn
        send(
            TdApi.SetAuthenticationPhoneNumber(
                phoneNumber,
                TdApi.PhoneNumberAuthenticationSettings(
                    /* allowFlashCall = */ false,
                    /* allowMissedCall = */ false,
                    /* isCurrentPhoneNumber = */ false,
                    /* hasUnknownPhoneNumber = */ false,
                    /* allowSmsRetrieverApi = */ false,
                    /* firebaseAuthenticationSettings = */ null,
                    /* authenticationTokens = */ arrayOf(),
                ),
            ),
        )
    }

    suspend fun submitCode(code: String) {
        _authState.value = AuthState.LoggingIn
        send(TdApi.CheckAuthenticationCode(code))
    }

    suspend fun submitPassword(password: String) {
        _authState.value = AuthState.LoggingIn
        send(TdApi.CheckAuthenticationPassword(password))
    }

    suspend fun logout() {
        send(TdApi.LogOut())
    }

    /** Generic escape hatch for chat-list/chat/report screens built in later phases. */
    suspend fun <T : TdApi.Object> send(function: TdApi.Function<T>): T {
        return suspendCancellableCoroutine { cont ->
            client.send(function) { result ->
                if (result is TdApi.Error) {
                    cont.resumeWithException(
                        RuntimeException("TDLib error ${result.code}: ${result.message}"),
                    )
                } else {
                    @Suppress("UNCHECKED_CAST")
                    cont.resume(result as T)
                }
            }
        }
    }

    private fun sendFireAndForget(function: TdApi.Function<*>) {
        client.send(function) { result ->
            if (result is TdApi.Error) {
                _authState.value = AuthState.Error("${result.code}: ${result.message}")
            }
        }
    }

    fun close() {
        client.send(TdApi.Close()) { /* ignore result */ }
        sessionScope.cancel()
    }
}
