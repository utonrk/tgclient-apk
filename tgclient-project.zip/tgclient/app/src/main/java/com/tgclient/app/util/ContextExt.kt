package com.tgclient.app.util

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineScope

/**
 * The lifecycle-aware coroutine scope of the Activity behind this
 * [Context], or null if this Context isn't backed by one (e.g. an
 * Application context). Every dialog/helper that needs to launch a
 * suspend TDLib call from a plain `Context` uses this instead of
 * repeating the `as? ComponentActivity` cast at each call site.
 */
val Context.activityScopeOrNull: CoroutineScope?
    get() = (this as? ComponentActivity)?.lifecycleScope
