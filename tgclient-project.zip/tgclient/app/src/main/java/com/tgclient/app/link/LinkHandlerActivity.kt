package com.tgclient.app.link

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.R
import com.tgclient.app.chat.ChatActivity
import com.tgclient.app.login.LoginActivity
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.drinkless.tdlib.TdApi

/**
 * No-UI entry point for `https://t.me/...` and `tg://...` links (opened from
 * outside the app — a browser, another app's share sheet, etc.). Resolves
 * the link via TDLib and hands off to [ChatActivity], then finishes itself;
 * it never stays on screen.
 */
class LinkHandlerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val session = AccountManager.getActiveSession()
        if (session == null) {
            toast(getString(R.string.status_link_login_first))
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        val uri = intent?.data
        val parsed = uri?.let { parseLink(it) }
        if (parsed == null) {
            finish()
            return
        }

        lifecycleScope.launch {
            // On a cold start (app not already running), TDLib's own
            // authState starts at Uninitialized and only flips to
            // Ready/WaitPhoneNumber/etc. once SetTdlibParameters round-trips
            // — which is near-instant (local, no network) but not
            // synchronous. Wait for that instead of trusting .value right away.
            val resolvedState = withTimeoutOrNull(5_000) {
                session.authState.first { it !is TdlibSession.AuthState.Uninitialized }
            }
            if (resolvedState !is TdlibSession.AuthState.Ready) {
                toast(getString(R.string.status_link_login_first))
                startActivity(Intent(this@LinkHandlerActivity, LoginActivity::class.java))
                finish()
                return@launch
            }

            when (parsed) {
                is ParsedLink.Username -> resolveUsername(session, parsed.username)
                is ParsedLink.Invite -> resolveInvite(session, parsed.link)
            }
        }
    }

    private sealed class ParsedLink {
        data class Username(val username: String) : ParsedLink()
        data class Invite(val link: String) : ParsedLink()
    }

    /**
     * Accepts both `https://t.me/...` links and `tg://resolve` /
     * `tg://join` deep links. Only the parts needed to identify a chat
     * (username, or the invite-link string as TDLib expects it) are
     * pulled out — everything else (message ids, extra query params) is
     * ignored.
     */
    private fun parseLink(uri: Uri): ParsedLink? {
        if (uri.scheme == "tg") {
            uri.getQueryParameter("domain")?.let { return ParsedLink.Username(it.removePrefix("@")) }
            uri.getQueryParameter("invite")?.let { return ParsedLink.Invite("https://t.me/+$it") }
            return null
        }

        val host = uri.host ?: return null
        if (host != "t.me" && host != "telegram.me") return null

        val segments = uri.pathSegments
        if (segments.isEmpty()) return null

        return when {
            segments[0].startsWith("+") -> ParsedLink.Invite(uri.toString())
            segments[0] == "joinchat" && segments.size > 1 -> ParsedLink.Invite(uri.toString())
            segments[0] in RESERVED_PATHS -> null
            else -> ParsedLink.Username(segments[0].removePrefix("@"))
        }
    }

    private suspend fun resolveUsername(session: TdlibSession, username: String) {
        runCatching { session.send(TdApi.SearchPublicChat(username)) }
            .onSuccess { openChat(session, it.id, it.title) }
            .onFailure { toast(getString(R.string.status_link_chat_not_found)) }
        finish()
    }

    private suspend fun resolveInvite(session: TdlibSession, link: String) {
        val info = runCatching { session.send(TdApi.CheckChatInviteLink(link)) }.getOrNull()
        if (info == null) {
            toast(getString(R.string.status_link_invalid))
            finish()
            return
        }

        if (info.chatId != 0L) {
            // Already have access (e.g. already a member) — no need to join again.
            openChat(session, info.chatId, info.title)
            finish()
            return
        }

        showJoinConfirmation(session, link, info)
    }

    private fun showJoinConfirmation(session: TdlibSession, link: String, info: TdApi.ChatInviteLinkInfo) {
        AlertDialog.Builder(this)
            .setTitle(info.title.ifBlank { getString(R.string.title_group_default) })
            .setMessage(
                resources.getQuantityString(R.plurals.member_count, info.memberCount, info.memberCount),
            )
            .setPositiveButton(R.string.action_join) { _, _ ->
                lifecycleScope.launch { doJoin(session, link) }
            }
            .setNegativeButton(R.string.action_cancel) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    private suspend fun doJoin(session: TdlibSession, link: String) {
        val result = runCatching { session.send(TdApi.JoinChatByInviteLink(link)) }.getOrNull()
        when (result) {
            is TdApi.ChatJoinResultSuccess -> openChat(session, result.chatId, "")
            is TdApi.ChatJoinResultRequestSent -> toast(getString(R.string.status_link_join_request_sent))
            else -> toast(getString(R.string.status_link_join_failed))
        }
        finish()
    }

    private suspend fun openChat(session: TdlibSession, chatId: Long, titleHint: String) {
        val title = titleHint.ifBlank {
            runCatching { session.send(TdApi.GetChat(chatId)) }.getOrNull()?.title ?: ""
        }
        ChatActivity.start(this, session.accountId, chatId, title)
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private val RESERVED_PATHS = setOf(
            "s", "share", "proxy", "addstickers", "addtheme", "addemoji",
            "iv", "login", "confirmphone", "setlanguage", "socks",
        )
    }
}
