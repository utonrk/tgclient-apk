package com.tgclient.app.chat

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.tdlib.ChatListItem
import com.tgclient.app.tdlib.ChatListRepository
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Simple "forward this one message to..." picker: reuses the same
 * ChatListRepository the chat-list screen uses, shows titles in a plain
 * list, forwards on tap.
 *
 * NOTE for whoever debugs a failed build next: TdApi.ForwardMessages'
 * exact parameter order has shifted across TDLib versions before (same
 * class of issue as the phone-number functions removed earlier in this
 * project). If compileDebugKotlin fails specifically on the line calling
 * TdApi.ForwardMessages(...) below, check the ForwardMessages constructor
 * in this project's own built org/drinkless/tdlib/TdApi.java/kt and match
 * its exact field order — the rest of the app does not depend on this file.
 */
class ForwardChatPickerDialog(
    private val context: Context,
    private val session: TdlibSession,
    private val fromChatId: Long,
    private val messageId: Long,
) {

    fun show() {
        val scope = (context as? androidx.activity.ComponentActivity)?.lifecycleScope ?: return
        val repo = ChatListRepository(session, scope)
        repo.start()

        scope.launch {
            repo.chatList.collect { chats ->
                if (chats.isEmpty()) return@collect
                repo.stop()
                showPicker(chats)
            }
        }
    }

    private fun showPicker(chats: List<ChatListItem>) {
        val titles = chats.map { it.title.ifBlank { "(tanpa nama)" } }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle("Forward ke...")
            .setItems(titles) { _, index ->
                forwardTo(chats[index].chatId)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /**
     * Confirmed against this project's own built java/org/drinkless/tdlib/TdApi.java:
     * ForwardMessages(long chatId, MessageTopic topicId, long fromChatId,
     *                  long[] messageIds, MessageSendOptions options,
     *                  boolean sendCopy, boolean removeCaption)
     * `topicId` is a MessageTopic (not a plain Long/thread-id like older TDLib
     * versions) — null means "no topic", per that constructor's own javadoc.
     */
    private fun forwardTo(targetChatId: Long) {
        val scope = (context as? androidx.activity.ComponentActivity)?.lifecycleScope ?: return
        scope.launch {
            runCatching {
                session.send(
                    TdApi.ForwardMessages(
                        targetChatId,
                        null,
                        fromChatId,
                        longArrayOf(messageId),
                        null,
                        false,
                        false,
                    ),
                )
            }.onSuccess {
                Toast.makeText(context, "Pesan diteruskan.", Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, "Gagal forward: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
