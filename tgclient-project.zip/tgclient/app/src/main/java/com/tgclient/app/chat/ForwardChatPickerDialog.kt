package com.tgclient.app.chat

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.tgclient.app.R
import com.tgclient.app.tdlib.ChatListItem
import com.tgclient.app.tdlib.TdlibSession
import com.tgclient.app.util.activityScopeOrNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Simple "forward this one message to..." picker. Reads from
 * `session.chatListRepository` — the same session-owned instance the main
 * chat-list screen uses — instead of spinning up a second one just for
 * this dialog.
 *
 * NOTE for whoever debugs a failed build next: TdApi.ForwardMessages'
 * exact parameter order has shifted across TDLib versions before (same
 * class of issue as the phone-number functions removed earlier in this
 * project). If compileDebugKotlin fails specifically on the line calling
 * TdApi.ForwardMessages(...) below, check the ForwardMessages constructor
 * in this project's own built org/drinkless/tdlib/TdApi.java/kt and match
 * its exact field order — the rest of the app does not depend on this file.
 */
class ForwardChatPickerDialog(
    private val context: Context,
    private val session: TdlibSession,
    private val fromChatId: Long,
    private val messageId: Long,
) {

    fun show() {
        val scope = context.activityScopeOrNull ?: return
        val repo = session.chatListRepository

        scope.launch {
            // Session-owned repo is shared/long-lived, so we must NOT keep
            // collecting after we get what we need — just take the first
            // non-empty snapshot (already loaded in the common case, since
            // you can only reach this dialog from an already-open chat).
            val chats = repo.chatList.first { it.isNotEmpty() }
            showPicker(chats)
        }
    }

    private fun showPicker(chats: List<ChatListItem>) {
        val titles = chats.map { it.title.ifBlank { "(tanpa nama)" } }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle(R.string.dialog_forward_title)
            .setItems(titles) { _, index ->
                forwardTo(chats[index].chatId)
            }
            .setNegativeButton(R.string.action_cancel, null)
            .show()
    }

    /**
     * Confirmed against this project's own built java/org/drinkless/tdlib/TdApi.java:
     * ForwardMessages(long chatId, MessageTopic topicId, long fromChatId,
     *                  long[] messageIds, MessageSendOptions options,
     *                  boolean sendCopy, boolean removeCaption)
     * `topicId` is a MessageTopic (not a plain Long/thread-id like older TDLib
     * versions) — null means "no topic", per that constructor's own javadoc.
     */
    private fun forwardTo(targetChatId: Long) {
        val scope = context.activityScopeOrNull ?: return
        scope.launch {
            runCatching {
                session.send(
                    TdApi.ForwardMessages(
                        targetChatId,
                        null,
                        fromChatId,
                        longArrayOf(messageId),
                        null,
                        false,
                        false,
                    ),
                )
            }.onSuccess {
                Toast.makeText(context, context.getString(R.string.status_forward_success), Toast.LENGTH_SHORT).show()
            }.onFailure {
                Toast.makeText(context, context.getString(R.string.status_forward_failed, it.message ?: ""), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
