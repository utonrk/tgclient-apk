package com.tgclient.app.tdlib

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists which account IDs exist and which one is currently active.
 * An "account ID" here is just a locally-generated string (UUID) used
 * to namespace each account's TDLib database directory — it has no
 * relation to the Telegram user ID until after login succeeds.
 */
class AccountStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAccountIds(): List<String> {
        val raw = prefs.getString(KEY_ACCOUNT_IDS, null) ?: return emptyList()
        if (raw.isBlank()) return emptyList()
        return raw.split(SEPARATOR).filter { it.isNotBlank() }
    }

    fun addAccountId(accountId: String) {
        val current = getAccountIds().toMutableList()
        if (!current.contains(accountId)) {
            current.add(accountId)
            saveAccountIds(current)
        }
    }

    fun removeAccountId(accountId: String) {
        val current = getAccountIds().toMutableList()
        current.remove(accountId)
        saveAccountIds(current)
        if (getActiveAccountId() == accountId) {
            setActiveAccountId(current.firstOrNull())
        }
    }

    fun getActiveAccountId(): String? = prefs.getString(KEY_ACTIVE_ACCOUNT, null)

    fun setActiveAccountId(accountId: String?) {
        prefs.edit().putString(KEY_ACTIVE_ACCOUNT, accountId).apply()
    }

    private fun saveAccountIds(ids: List<String>) {
        prefs.edit().putString(KEY_ACCOUNT_IDS, ids.joinToString(SEPARATOR)).apply()
    }

    companion object {
        private const val PREFS_NAME = "tgclient_accounts"
        private const val KEY_ACCOUNT_IDS = "account_ids"
        private const val KEY_ACTIVE_ACCOUNT = "active_account_id"
        private const val SEPARATOR = ","
    }
}
