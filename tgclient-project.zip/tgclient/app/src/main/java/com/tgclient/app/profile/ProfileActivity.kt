package com.tgclient.app.profile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.R
import com.tgclient.app.report.ReportDialog
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Two modes, chosen by whether [EXTRA_USER_ID] is present:
 *  - own profile: no userId extra -> live-updates from TdlibSession.profile
 *  - another user's profile: userId extra set -> one-shot TdApi.GetUser /
 *    GetUserFullInfo fetch, with a "Report" entry point.
 */
class ProfileActivity : AppCompatActivity() {

    private lateinit var session: TdlibSession
    private var otherUserId: Long = 0L
    private var reportChatId: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID)
        session = accountId?.let { AccountManager.getSession(it) }
            ?: AccountManager.getActiveSession()
            ?: run { finish(); return }

        otherUserId = intent.getLongExtra(EXTRA_USER_ID, 0L)
        reportChatId = intent.getLongExtra(EXTRA_REPORT_CHAT_ID, 0L)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val nameView = findViewById<TextView>(R.id.profileName)
        val usernameView = findViewById<TextView>(R.id.profileUsername)
        val phoneView = findViewById<TextView>(R.id.profilePhone)
        val bioView = findViewById<TextView>(R.id.profileBio)
        val reportButton = findViewById<Button>(R.id.reportButton)

        if (otherUserId == 0L) {
            title = getString(R.string.title_my_profile)
            lifecycleScope.launch {
                session.profile.collect { profile ->
                    nameView.text = "${profile.firstName} ${profile.lastName}".trim()
                        .ifBlank { "(Belum ada nama)" }
                    usernameView.text = profile.username.takeIf { it.isNotBlank() }?.let { "@$it" } ?: ""
                    phoneView.text = profile.phoneNumber.takeIf { it.isNotBlank() }?.let { "+$it" } ?: ""
                }
            }
        } else {
            title = getString(R.string.title_user_profile)
            reportButton.visibility = android.view.View.VISIBLE
            reportButton.setOnClickListener {
                if (reportChatId != 0L) {
                    ReportDialog(this, session, reportChatId).show()
                }
            }
            lifecycleScope.launch {
                runCatching { session.send(TdApi.GetUser(otherUserId)) }
                    .onSuccess { user ->
                        nameView.text = "${user.firstName} ${user.lastName}".trim()
                            .ifBlank { "(Tanpa nama)" }
                        val username = user.usernames?.editableUsername
                        usernameView.text = username?.takeIf { it.isNotBlank() }?.let { "@$it" } ?: ""
                        phoneView.text = user.phoneNumber?.takeIf { it.isNotBlank() }?.let { "+$it" } ?: ""
                    }
                runCatching { session.send(TdApi.GetUserFullInfo(otherUserId)) }
                    .onSuccess { full -> bioView.text = full.bio?.text ?: "" }
            }
        }
    }

    companion object {
        private const val EXTRA_ACCOUNT_ID = "account_id"
        private const val EXTRA_USER_ID = "user_id"
        private const val EXTRA_REPORT_CHAT_ID = "report_chat_id"

        /** Open the signed-in user's own profile. */
        fun startForSelf(context: Context, accountId: String) {
            context.startActivity(
                Intent(context, ProfileActivity::class.java)
                    .putExtra(EXTRA_ACCOUNT_ID, accountId),
            )
        }

        /** Open another user's profile, with a Report button wired to [reportChatId]. */
        fun startForUser(context: Context, accountId: String, userId: Long, reportChatId: Long) {
            context.startActivity(
                Intent(context, ProfileActivity::class.java)
                    .putExtra(EXTRA_ACCOUNT_ID, accountId)
                    .putExtra(EXTRA_USER_ID, userId)
                    .putExtra(EXTRA_REPORT_CHAT_ID, reportChatId),
            )
        }
    }
}
