package com.tgclient.app.profile

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.tgclient.app.R
import com.tgclient.app.report.ReportDialog
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Two modes, chosen by whether [EXTRA_USER_ID] is present:
 *  - own profile: no userId extra -> live-updates from TdlibSession.profile,
 *    with pencil icons to edit name/username/bio/phone in place.
 *  - another user's profile: userId extra set -> one-shot TdApi.GetUser /
 *    GetUserFullInfo fetch, with a "Report" entry point, no editing.
 */
class ProfileActivity : AppCompatActivity() {

    private lateinit var session: TdlibSession
    private var otherUserId: Long = 0L
    private var reportChatId: Long = 0L

    private lateinit var avatarInitial: TextView
    private lateinit var nameView: TextView
    private lateinit var usernameHeaderView: TextView
    private lateinit var rowNameValue: TextView
    private lateinit var rowUsernameValue: TextView
    private lateinit var phoneView: TextView
    private lateinit var bioView: TextView

    private var currentFirstName: String = ""
    private var currentLastName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID)
        session = accountId?.let { AccountManager.getSession(it) }
            ?: AccountManager.getActiveSession()
            ?: run { finish(); return }

        otherUserId = intent.getLongExtra(EXTRA_USER_ID, 0L)
        reportChatId = intent.getLongExtra(EXTRA_REPORT_CHAT_ID, 0L)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        avatarInitial = findViewById(R.id.profileAvatarInitial)
        nameView = findViewById(R.id.profileName)
        usernameHeaderView = findViewById(R.id.profileUsername)
        rowNameValue = findViewById(R.id.rowNameValue)
        rowUsernameValue = findViewById(R.id.rowUsernameValue)
        phoneView = findViewById(R.id.profilePhone)
        bioView = findViewById(R.id.profileBio)
        val reportButton = findViewById<MaterialButton>(R.id.reportButton)

        if (otherUserId == 0L) {
            title = getString(R.string.title_my_profile)
            showEditButtons()

            lifecycleScope.launch {
                session.profile.collect { profile ->
                    currentFirstName = profile.firstName
                    currentLastName = profile.lastName
                    val fullName = "${profile.firstName} ${profile.lastName}".trim()
                        .ifBlank { "(Belum ada nama)" }
                    val username = profile.username.takeIf { it.isNotBlank() }

                    avatarInitial.text = (profile.firstName.firstOrNull() ?: '?').toString().uppercase()
                    nameView.text = fullName
                    usernameHeaderView.text = username?.let { "@$it" } ?: ""
                    rowNameValue.text = fullName
                    rowUsernameValue.text = username?.let { "@$it" } ?: getString(R.string.username_not_set)
                    phoneView.text = profile.phoneNumber.takeIf { it.isNotBlank() }?.let { "+$it" } ?: ""
                }
            }

            // Bio isn't part of TdlibSession.profile (that only tracks fields
            // from UpdateUser); fetch it once via GetUserFullInfo on my own id.
            lifecycleScope.launch {
                runCatching { session.send(TdApi.GetMe()) }
                    .onSuccess { me ->
                        runCatching { session.send(TdApi.GetUserFullInfo(me.id)) }
                            .onSuccess { full ->
                                bioView.text = full.bio?.text?.takeIf { it.isNotBlank() }
                                    ?: getString(R.string.bio_not_set)
                            }
                    }
            }
        } else {
            title = getString(R.string.title_user_profile)
            reportButton.visibility = View.VISIBLE
            reportButton.setOnClickListener {
                if (reportChatId != 0L) {
                    ReportDialog(this, session, reportChatId).show()
                }
            }
            lifecycleScope.launch {
                runCatching { session.send(TdApi.GetUser(otherUserId)) }
                    .onSuccess { user ->
                        val fullName = "${user.firstName} ${user.lastName}".trim()
                            .ifBlank { "(Tanpa nama)" }
                        val username = user.usernames?.editableUsername?.takeIf { it.isNotBlank() }
                        avatarInitial.text = (user.firstName.firstOrNull() ?: '?').toString().uppercase()
                        nameView.text = fullName
                        usernameHeaderView.text = username?.let { "@$it" } ?: ""
                        rowNameValue.text = fullName
                        rowUsernameValue.text = username?.let { "@$it" } ?: getString(R.string.username_not_set)
                        phoneView.text = user.phoneNumber?.takeIf { it.isNotBlank() }?.let { "+$it" } ?: ""
                    }
                runCatching { session.send(TdApi.GetUserFullInfo(otherUserId)) }
                    .onSuccess { full ->
                        bioView.text = full.bio?.text?.takeIf { it.isNotBlank() } ?: getString(R.string.bio_not_set)
                    }
            }
        }
    }

    private fun showEditButtons() {
        findViewById<ImageButton>(R.id.editNameButton).apply {
            visibility = View.VISIBLE
            setOnClickListener { showEditNameDialog() }
        }
        findViewById<ImageButton>(R.id.editUsernameButton).apply {
            visibility = View.VISIBLE
            setOnClickListener { showEditUsernameDialog() }
        }
        findViewById<ImageButton>(R.id.editBioButton).apply {
            visibility = View.VISIBLE
            setOnClickListener { showEditBioDialog() }
        }
        // Nomor telepon sengaja TIDAK dibuat bisa diedit dari sini: TDLib
        // versi yang di-build tidak punya ChangePhoneNumber/CheckChangePhoneNumberCode
        // dengan tanda tangan yang saya asumsikan, dan ini operasi sensitif
        // (mengganti nomor akun asli) — lebih aman ditampilkan read-only saja.
    }

    private fun showEditNameDialog() {
        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val firstNameInput = EditText(this).apply {
            hint = getString(R.string.hint_first_name)
            setText(currentFirstName)
        }
        val lastNameInput = EditText(this).apply {
            hint = getString(R.string.hint_last_name)
            setText(currentLastName)
        }
        container.addView(firstNameInput)
        container.addView(lastNameInput)

        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_edit_name_title)
            .setView(container)
            .setPositiveButton(R.string.action_save) { _, _ ->
                val firstName = firstNameInput.text.toString().trim()
                val lastName = lastNameInput.text.toString().trim()
                lifecycleScope.launch {
                    runCatching { session.send(TdApi.SetName(firstName, lastName)) }
                        .onSuccess { toast(getString(R.string.profile_update_success)) }
                        .onFailure { toast(getString(R.string.profile_update_failed, it.message ?: "")) }
                }
            }
            .setNegativeButton(R.string.action_cancel, null)
            .show()
    }

    private fun showEditUsernameDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.hint_username)
            setText(rowUsernameValue.text.toString().removePrefix("@").let {
                if (it == getString(R.string.username_not_set)) "" else it
            })
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_edit_username_title)
            .setView(input)
            .setPositiveButton(R.string.action_save) { _, _ ->
                val username = input.text.toString().trim().removePrefix("@")
                lifecycleScope.launch {
                    runCatching { session.send(TdApi.SetUsername(username)) }
                        .onSuccess { toast(getString(R.string.profile_update_success)) }
                        .onFailure { toast(getString(R.string.profile_update_failed, it.message ?: "")) }
                }
            }
            .setNegativeButton(R.string.action_cancel, null)
            .show()
    }

    private fun showEditBioDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.hint_bio)
            setText(bioView.text.toString().let {
                if (it == getString(R.string.bio_not_set)) "" else it
            })
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_edit_bio_title)
            .setView(input)
            .setPositiveButton(R.string.action_save) { _, _ ->
                val bio = input.text.toString().trim()
                lifecycleScope.launch {
                    runCatching { session.send(TdApi.SetBio(bio)) }
                        .onSuccess {
                            bioView.text = bio.takeIf { it.isNotBlank() } ?: getString(R.string.bio_not_set)
                            toast(getString(R.string.profile_update_success))
                        }
                        .onFailure { toast(getString(R.string.profile_update_failed, it.message ?: "")) }
                }
            }
            .setNegativeButton(R.string.action_cancel, null)
            .show()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val EXTRA_ACCOUNT_ID = "account_id"
        private const val EXTRA_USER_ID = "user_id"
        private const val EXTRA_REPORT_CHAT_ID = "report_chat_id"

        /** Open the signed-in user's own profile (editable). */
        fun startForSelf(context: Context, accountId: String) {
            context.startActivity(
                Intent(context, ProfileActivity::class.java)
                    .putExtra(EXTRA_ACCOUNT_ID, accountId),
            )
        }

        /** Open another user's profile, with a Report button wired to [reportChatId]. */
        fun startForUser(context: Context, accountId: String, userId: Long, reportChatId: Long) {
            context.startActivity(
                Intent(context, ProfileActivity::class.java)
                    .putExtra(EXTRA_ACCOUNT_ID, accountId)
                    .putExtra(EXTRA_USER_ID, userId)
                    .putExtra(EXTRA_REPORT_CHAT_ID, reportChatId),
            )
        }
    }
}
