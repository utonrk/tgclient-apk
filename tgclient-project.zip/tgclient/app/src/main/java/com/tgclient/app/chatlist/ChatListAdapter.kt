package com.tgclient.app.chatlist

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.R
import com.tgclient.app.tdlib.ChatListItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatListAdapter(
    private val onClick: (ChatListItem) -> Unit,
) : RecyclerView.Adapter<ChatListAdapter.ViewHolder>() {

    private var items: List<ChatListItem> = emptyList()
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    // Same idea as Telegram's own avatar palette: pick a color deterministically
    // from the chat title so the same chat always gets the same color.
    private val avatarColors = intArrayOf(
        0xFFE17076.toInt(), 0xFFEDA86C.toInt(), 0xFFA695E7.toInt(),
        0xFF7BC862.toInt(), 0xFF6EC9CB.toInt(), 0xFF65AADD.toInt(),
        0xFFEE7AAE.toInt(),
    )

    fun submitList(newItems: List<ChatListItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val avatar: TextView = view.findViewById(R.id.chatAvatar)
        val title: TextView = view.findViewById(R.id.chatTitle)
        val preview: TextView = view.findViewById(R.id.chatPreview)
        val time: TextView = view.findViewById(R.id.chatTime)
        val unread: TextView = view.findViewById(R.id.chatUnreadBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val displayTitle = item.title.ifBlank { "(Tanpa nama)" }
        holder.title.text = displayTitle
        holder.preview.text = item.lastMessagePreview
        holder.time.text = if (item.lastMessageTimeSeconds > 0) {
            timeFormat.format(Date(item.lastMessageTimeSeconds.toLong() * 1000L))
        } else {
            ""
        }
        if (item.unreadCount > 0) {
            holder.unread.visibility = android.view.View.VISIBLE
            holder.unread.text = item.unreadCount.toString()
        } else {
            holder.unread.visibility = android.view.View.GONE
        }

        holder.avatar.text = displayTitle.trim().firstOrNull()?.uppercase() ?: "?"
        val color = avatarColors[(item.chatId.hashCode() and Int.MAX_VALUE) % avatarColors.size]
        (holder.avatar.background.mutate() as? GradientDrawable)?.setColor(color)

        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size
}
