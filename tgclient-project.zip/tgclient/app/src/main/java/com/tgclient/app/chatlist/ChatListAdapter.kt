package com.tgclient.app.chatlist

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.R
import com.tgclient.app.tdlib.ChatListItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatListAdapter(
    private val onClick: (ChatListItem) -> Unit,
) : ListAdapter<ChatListItem, ChatListAdapter.ViewHolder>(DIFF_CALLBACK) {

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.chatTitle)
        val preview: TextView = view.findViewById(R.id.chatPreview)
        val time: TextView = view.findViewById(R.id.chatTime)
        val unread: TextView = view.findViewById(R.id.chatUnreadBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.title.text = item.title.ifBlank { "(Tanpa nama)" }
        holder.preview.text = item.lastMessagePreview
        holder.time.text = if (item.lastMessageTimeSeconds > 0) {
            timeFormat.format(Date(item.lastMessageTimeSeconds.toLong() * 1000L))
        } else {
            ""
        }
        if (item.unreadCount > 0) {
            holder.unread.visibility = android.view.View.VISIBLE
            holder.unread.text = item.unreadCount.toString()
        } else {
            holder.unread.visibility = android.view.View.GONE
        }
        holder.itemView.setOnClickListener { onClick(item) }
    }

    companion object {
        // ChatListItem is a data class, so equals()/hashCode() already compare
        // every field — DiffUtil uses that directly instead of us hand-rolling
        // per-field comparisons here.
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ChatListItem>() {
            override fun areItemsTheSame(oldItem: ChatListItem, newItem: ChatListItem) =
                oldItem.chatId == newItem.chatId

            override fun areContentsTheSame(oldItem: ChatListItem, newItem: ChatListItem) =
                oldItem == newItem
        }
    }
}
