package com.tgclient.app.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.ChatRepository

/**
 * Owns one [ChatRepository] for the lifetime of the chat screen (survives
 * rotation, cleared when the screen is actually finished). Kept per-screen
 * rather than per-session like [com.tgclient.app.tdlib.ChatListRepository]
 * so message history for chats you're not currently viewing doesn't pile
 * up in memory.
 */
class ChatViewModel(accountId: String, chatId: Long) : ViewModel() {

    val repository: ChatRepository? = AccountManager.getSession(accountId)?.let { session ->
        ChatRepository(session, chatId, viewModelScope).also { it.start() }
    }

    override fun onCleared() {
        repository?.stop()
    }

    class Factory(private val accountId: String, private val chatId: Long) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChatViewModel(accountId, chatId) as T
        }
    }
}
