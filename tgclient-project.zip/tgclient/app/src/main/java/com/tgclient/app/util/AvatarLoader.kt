package com.tgclient.app.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.drinkless.tdlib.TdApi

/**
 * Downloads and decodes chat/user avatar photos via TDLib, with a small
 * in-memory cache keyed by TDLib file id so the same photo isn't
 * re-downloaded/re-decoded every time a row or dialog rebinds.
 *
 * `synchronous = true` on DownloadFile is what lets this stay a single
 * suspend call instead of needing to listen for TdApi.UpdateFile: TDLib
 * blocks its own worker thread until the (small, avatar-sized) file is
 * fully on disk before returning.
 */
object AvatarLoader {

    private val cache = LruCache<Int, Bitmap>(60)

    /** Loads the small (list-sized) avatar for a user, chat, or group photo. */
    suspend fun loadSmall(session: TdlibSession, photo: TdApi.ChatPhotoInfo?): Bitmap? =
        load(session, photo?.small)

    /** Loads the big (profile-viewer-sized) avatar, falling back to small if unavailable. */
    suspend fun loadBig(session: TdlibSession, photo: TdApi.ChatPhotoInfo?): Bitmap? =
        load(session, photo?.big) ?: load(session, photo?.small)

    private suspend fun load(session: TdlibSession, file: TdApi.File?): Bitmap? {
        if (file == null) return null
        cache.get(file.id)?.let { return it }

        val path = if (file.local?.isDownloadingCompleted == true) {
            file.local?.path
        } else {
            runCatching {
                session.send(TdApi.DownloadFile(file.id, 1, 0, 0, true)).local?.path
            }.getOrNull()
        }
        if (path.isNullOrBlank()) return null

        return withContext(Dispatchers.IO) {
            runCatching { BitmapFactory.decodeFile(path) }.getOrNull()
        }?.also { cache.put(file.id, it) }
    }
}
