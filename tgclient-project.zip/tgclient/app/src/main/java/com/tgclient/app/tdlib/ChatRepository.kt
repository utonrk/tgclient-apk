package com.tgclient.app.tdlib

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

data class MessageItem(
    val messageId: Long,
    val text: String,
    val isOutgoing: Boolean,
    val dateSeconds: Int,
)

/**
 * Loads and keeps in sync the message history for exactly one chat, for
 * one [TdlibSession]. Create one per open [com.tgclient.app.chat.ChatActivity]
 * and call [start] once the screen is visible.
 */
class ChatRepository(
    private val session: TdlibSession,
    private val chatId: Long,
    private val scope: CoroutineScope,
) {

    private val messagesById = LinkedHashMap<Long, TdApi.Message>()

    private val _messages = MutableStateFlow<List<MessageItem>>(emptyList())
    val messages: StateFlow<List<MessageItem>> = _messages.asStateFlow()

    private var job: Job? = null

    fun start() {
        if (job != null) return
        job = scope.launch {
            session.updates.collect { update -> handleUpdate(update) }
        }
        scope.launch { loadHistory() }
        // Best-effort: let the other side know these messages were seen.
        scope.launch {
            runCatching { session.send(TdApi.OpenChat(chatId)) }
        }
    }

    fun stop() {
        scope.launch { runCatching { session.send(TdApi.CloseChat(chatId)) } }
        job?.cancel()
        job = null
    }

    suspend fun sendText(text: String) {
        if (text.isBlank()) return
        session.send(
            TdApi.SendMessage(
                chatId,
                /* messageTopic = */ null,
                /* replyTo = */ null,
                /* options = */ TdApi.MessageSendOptions(),
                /* replyMarkup = */ null,
                /* inputMessageContent = */ TdApi.InputMessageText(
                    TdApi.FormattedText(text, arrayOf()),
                    null,
                    false,
                ),
            ),
        )
    }

    private suspend fun loadHistory() {
        runCatching {
            session.send(
                TdApi.GetChatHistory(chatId, /* fromMessageId = */ 0, /* offset = */ 0, /* limit = */ 50, /* onlyLocal = */ false),
            )
        }.onSuccess { result ->
            (result as? TdApi.Messages)?.messages?.filterNotNull()?.forEach { message ->
                messagesById[message.id] = message
            }
            publish()
        }
    }

    private fun handleUpdate(update: TdApi.Object) {
        when (update) {
            is TdApi.UpdateNewMessage -> {
                if (update.message.chatId == chatId) {
                    messagesById[update.message.id] = update.message
                    publish()
                }
            }
            is TdApi.UpdateMessageContent -> {
                if (update.chatId == chatId) {
                    messagesById[update.messageId]?.content = update.newContent
                    publish()
                }
            }
            is TdApi.UpdateMessageSendSucceeded -> {
                if (update.message.chatId == chatId) {
                    messagesById.remove(update.oldMessageId)
                    messagesById[update.message.id] = update.message
                    publish()
                }
            }
            else -> Unit
        }
    }

    private fun publish() {
        _messages.value = messagesById.values
            .sortedBy { it.id }
            .map { message ->
                MessageItem(
                    messageId = message.id,
                    text = textOf(message.content),
                    isOutgoing = message.isOutgoing,
                    dateSeconds = message.date,
                )
            }
    }

    private fun textOf(content: TdApi.MessageContent): String = when (content) {
        is TdApi.MessageText -> content.text.text
        is TdApi.MessagePhoto -> "\uD83D\uDCF7 Foto" + (content.caption?.text?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "")
        is TdApi.MessageVideo -> "\uD83C\uDFA5 Video"
        is TdApi.MessageDocument -> "\uD83D\uDCC4 " + (content.document?.fileName ?: "Dokumen")
        is TdApi.MessageSticker -> "${content.sticker?.emoji ?: "\uD83C\uDFB4"} Stiker"
        is TdApi.MessageVoiceNote -> "\uD83C\uDFA4 Pesan suara"
        is TdApi.MessageCall -> "\uD83D\uDCDE Panggilan"
        else -> "[pesan]"
    }
}
