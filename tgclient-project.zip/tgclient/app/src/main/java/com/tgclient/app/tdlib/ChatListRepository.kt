package com.tgclient.app.tdlib

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Keeps the "main" chat list (TdApi.ChatListMain) for one [TdlibSession] up
 * to date by listening to that session's raw update stream.
 *
 * Owned by [TdlibSession] itself (`session.chatListRepository`), not by any
 * one screen — it lives as long as the session does, so every screen that
 * needs the chat list (the chat-list screen, the forward picker, ...)
 * shares one instance instead of each reloading it from scratch.
 */
class ChatListRepository(
    private val session: TdlibSession,
    private val scope: CoroutineScope,
) {

    private val chatsById = mutableMapOf<Long, TdApi.Chat>()

    private val _chatList = MutableStateFlow<List<ChatListItem>>(emptyList())
    val chatList: StateFlow<List<ChatListItem>> = _chatList.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private var job: Job? = null
    private var requestedInitialLoad = false

    fun start() {
        if (job != null) return
        job = scope.launch {
            session.updates.collect { update -> handleUpdate(update) }
        }
        scope.launch { requestInitialLoad() }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    private suspend fun requestInitialLoad() {
        if (requestedInitialLoad) return
        requestedInitialLoad = true
        // LoadChats asks TDLib to make sure enough chats are loaded into
        // this list; it commonly finishes with an error once everything is
        // already loaded, which is expected and safe to ignore.
        runCatching { session.send(TdApi.LoadChats(TdApi.ChatListMain(), 100)) }
        // GetChats returns nothing we need directly (we read state from the
        // updateNewChat/updateChatPosition stream instead), but issuing it
        // is what makes TDLib start pushing those updates for this list.
        runCatching { session.send(TdApi.GetChats(TdApi.ChatListMain(), 100)) }
        _isLoading.value = false
    }

    private fun handleUpdate(update: TdApi.Object) {
        when (update) {
            is TdApi.UpdateNewChat -> {
                chatsById[update.chat.id] = update.chat
                publish()
            }
            is TdApi.UpdateChatLastMessage -> {
                chatsById[update.chatId]?.let { chat ->
                    chat.lastMessage = update.lastMessage
                    update.positions?.let { chat.positions = it }
                }
                publish()
            }
            is TdApi.UpdateChatPosition -> {
                chatsById[update.chatId]?.let { chat ->
                    val kept = (chat.positions ?: emptyArray()).filter {
                        it.list::class != update.position.list::class
                    }
                    val next = if (update.position.order != 0L) kept + update.position else kept
                    chat.positions = next.toTypedArray()
                }
                publish()
            }
            is TdApi.UpdateChatReadInbox -> {
                chatsById[update.chatId]?.let { it.unreadCount = update.unreadCount }
                publish()
            }
            is TdApi.UpdateChatTitle -> {
                chatsById[update.chatId]?.let { it.title = update.title }
                publish()
            }
            is TdApi.UpdateChatPhoto -> {
                chatsById[update.chatId]?.let { it.photo = update.photo }
                publish()
            }
            is TdApi.UpdateChatDraftMessage -> {
                chatsById[update.chatId]?.let {
                    update.positions?.let { positions -> it.positions = positions }
                }
                publish()
            }
            else -> Unit
        }
    }

    private fun publish() {
        _chatList.value = chatsById.values
            .mapNotNull { chat ->
                val order = chat.positions
                    ?.firstOrNull { it.list is TdApi.ChatListMain }
                    ?.order ?: 0L
                if (order == 0L) return@mapNotNull null
                ChatListItem(
                    chatId = chat.id,
                    title = chat.title,
                    lastMessagePreview = MessageContentText.of(chat.lastMessage?.content),
                    lastMessageTimeSeconds = chat.lastMessage?.date ?: 0,
                    unreadCount = chat.unreadCount,
                    order = order,
                    photo = chat.photo,
                    chatType = chat.type,
                )
            }
            .sortedByDescending { it.order }
    }
}
