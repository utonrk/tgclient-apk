package com.tgclient.app.report

import android.content.Context
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * The normal, one-shot "report this chat / message" dialog every Telegram
 * client exposes (Settings > report, or long-press a message > Report).
 * This reports ONCE, from the currently active account only — it is not a
 * batch or multi-account tool.
 *
 * @param messageIds optional specific messages being reported (e.g. from a
 *   long-press in the chat screen); empty means "report the chat/user".
 */
class ReportDialog(
    private val context: Context,
    private val session: TdlibSession,
    private val chatId: Long,
    private val messageIds: LongArray = LongArray(0),
) {

    private data class Reason(val label: String, val build: () -> TdApi.ReportReason)

    private val reasons = listOf(
        Reason("Spam") { TdApi.ReportReasonSpam() },
        Reason("Akun/konten palsu") { TdApi.ReportReasonFake() },
        Reason("Kekerasan") { TdApi.ReportReasonViolence() },
        Reason("Pornografi") { TdApi.ReportReasonPornography() },
        Reason("Eksploitasi anak") { TdApi.ReportReasonChildAbuse() },
        Reason("Pelanggaran hak cipta") { TdApi.ReportReasonCopyright() },
        Reason("Narkoba ilegal") { TdApi.ReportReasonIllegalDrugs() },
        Reason("Membagikan data pribadi orang lain") { TdApi.ReportReasonPersonalDetails() },
        Reason("Lainnya") { TdApi.ReportReasonCustom() },
    )

    fun show() {
        val labels = reasons.map { it.label }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle("Laporkan")
            .setItems(labels) { _, index -> submit(reasons[index]) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun submit(reason: Reason) {
        val owner = (context as? androidx.activity.ComponentActivity)
        val scope = owner?.lifecycleScope ?: return
        scope.launch {
            runCatching {
                session.send(
                    TdApi.ReportChat(chatId, messageIds, reason.build(), ""),
                )
            }.onSuccess {
                Toast.makeText(context, "Laporan terkirim.", Toast.LENGTH_SHORT).show()
            }.onFailure { e ->
                Toast.makeText(context, "Gagal mengirim laporan: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
