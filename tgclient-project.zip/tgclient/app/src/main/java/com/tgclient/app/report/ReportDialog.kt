package com.tgclient.app.report

import android.content.Context
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * The normal, one-shot "report this chat / message" dialog every Telegram
 * client exposes (Settings > report, or long-press a message > Report).
 *
 * Current TDLib drives this as a short server-guided flow instead of a
 * fixed enum: you call ReportChat with an option id (empty the very first
 * time) and it replies with either "done", "pick one of these sub-reasons"
 * (ReportChatResultOptionRequired), or "type some free text"
 * (ReportChatResultTextRequired) — repeat until it says Ok. This still
 * reports ONCE, from the currently active account only; it is not a batch
 * or multi-account tool.
 */
class ReportDialog(
    private val context: Context,
    private val session: TdlibSession,
    private val chatId: Long,
    private val messageIds: LongArray = LongArray(0),
) {

    fun show() {
        launch { step(optionId = ByteArray(0), text = "") }
    }

    private suspend fun step(optionId: ByteArray, text: String) {
        val result = runCatching {
            session.send(TdApi.ReportChat(chatId, messageIds, optionId, text))
        }.getOrElse { e ->
            toast("Gagal mengirim laporan: ${e.message}")
            return
        }

        when (result) {
            is TdApi.ReportChatResultOk -> toast("Laporan terkirim.")
            is TdApi.ReportChatResultOptionRequired -> showOptions(result)
            is TdApi.ReportChatResultTextRequired -> showTextPrompt(result.optionId, result.isOptional)
            is TdApi.ReportChatResultMessagesRequired ->
                toast("Pilih pesan yang mau dilaporkan dulu (long-press pesan itu).")
            else -> toast("Laporan tidak bisa diproses.")
        }
    }

    private fun showOptions(result: TdApi.ReportChatResultOptionRequired) {
        val options = result.options ?: return
        val labels = options.map { it.text }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle(result.title.ifBlank { "Laporkan" })
            .setItems(labels) { _, index -> launch { step(options[index].id, "") } }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showTextPrompt(optionId: ByteArray, isOptional: Boolean) {
        val input = EditText(context)
        AlertDialog.Builder(context)
            .setTitle(if (isOptional) "Detail tambahan (opsional)" else "Jelaskan laporanmu")
            .setView(input)
            .setPositiveButton("Kirim") { _, _ -> launch { step(optionId, input.text.toString()) } }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun launch(block: suspend () -> Unit) {
        val scope = (context as? androidx.activity.ComponentActivity)?.lifecycleScope ?: return
        scope.launch { block() }
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
