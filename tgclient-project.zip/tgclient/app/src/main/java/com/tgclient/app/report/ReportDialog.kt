package com.tgclient.app.report

import android.content.Context
import android.content.ContextWrapper
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * Mass Report menggunakan 1 sesi aktif (single session).
 * Menentukan opsi laporan sekali, lalu mengirimkannya berulang kali (looping) secara otomatis.
 */
class MassReportDialog(
    private val context: Context,
    private val session: TdlibSession,
    private val chatId: Long,
    private val messageIds: LongArray = LongArray(0),
    private val repeatCount: Int = 10,       // Berapa kali laporan diulang
    private val delayBetweenMs: Long = 1000L, // Jeda antar pengiriman (mencegah FLOOD_WAIT)
    private val scope: CoroutineScope? = null
) {

    fun show() {
        launch { resolvePayload(optionId = ByteArray(0), text = "") }
    }

    // Fase 1: Mengambil opsi laporan dari server Telegram (hanya dipanggil 1 kali)
    private suspend fun resolvePayload(optionId: ByteArray, text: String) {
        val result = runCatching {
            session.send(TdApi.ReportChat(chatId, optionId, messageIds, text))
        }.getOrElse { e ->
            toast("Gagal mendapatkan opsi laporan: ${e.message}")
            return
        }

        when (result) {
            is TdApi.ReportChatResultOk -> startMassReportLoop(optionId, text)
            is TdApi.ReportChatResultOptionRequired -> showOptions(result)
            is TdApi.ReportChatResultTextRequired -> showTextPrompt(result.optionId, result.isOptional)
            is TdApi.ReportChatResultMessagesRequired ->
                toast("Pilih pesan yang mau dilaporkan terlebih dahulu.")
            else -> toast("Opsi laporan tidak dapat diproses.")
        }
    }

    private fun showOptions(result: TdApi.ReportChatResultOptionRequired) {
        val options = result.options ?: return
        if (options.isEmpty()) return

        val labels = options.map { it.text }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle("${result.title.ifBlank { "Mass Report" }} ($repeatCount x)")
            .setItems(labels) { _, index ->
                launch { resolvePayload(options[index].id, "") }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun showTextPrompt(optionId: ByteArray, isOptional: Boolean) {
        val input = EditText(context).apply {
            hint = if (isOptional) "Catatan tambahan..." else "Jelaskan alasan pelaporan..."
        }

        val container = FrameLayout(context).apply {
            val paddingPx = (16 * context.resources.displayMetrics.density).toInt()
            setPadding(paddingPx, paddingPx / 2, paddingPx, 0)
            addView(input)
        }

        AlertDialog.Builder(context)
            .setTitle(if (isOptional) "Detail Tambahan" else "Jelaskan Laporanmu")
            .setView(container)
            .setPositiveButton("Mulai Mass Report ($repeatCount x)") { _, _ ->
                val userText = input.text.toString().trim()
                launch { resolvePayload(optionId, userText) }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // Fase 2: Eksekusi pengiriman berulang (Mass Report) menggunakan 1 sesi
    private suspend fun startMassReportLoop(optionId: ByteArray, text: String) {
        toast("Memulai Mass Report $repeatCount kali...")

        var successCount = 0
        var failCount = 0

        for (i in 1..repeatCount) {
            val isSuccess = runCatching {
                val res = session.send(TdApi.ReportChat(chatId, optionId, messageIds, text))
                res is TdApi.ReportChatResultOk
            }.getOrDefault(false)

            if (isSuccess) successCount++ else failCount++

            // Jeda antar-request agar tidak langsung diblokir FLOOD_WAIT oleh server
            if (i < repeatCount) {
                delay(delayBetweenMs)
            }
        }

        toast("Mass Report Selesai!\nSukses: $successCount | Gagal: $failCount")
    }

    private fun launch(block: suspend () -> Unit) {
        val coroutineScope = scope ?: findActivity(context)?.lifecycleScope
        if (coroutineScope == null) {
            toast("Gagal menjalankan aksi: Lifecycle Context tidak ditemukan.")
            return
        }
        coroutineScope.launch { block() }
    }

    private fun findActivity(context: Context?): ComponentActivity? {
        var currentContext = context
        while (currentContext is ContextWrapper) {
            if (currentContext is ComponentActivity) return currentContext
            currentContext = currentContext.baseContext
        }
        return null
    }

    private fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
