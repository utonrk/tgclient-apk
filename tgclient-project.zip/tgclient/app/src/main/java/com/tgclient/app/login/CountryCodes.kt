package com.tgclient.app.login

/** One entry in the login screen's country-code dropdown. */
data class Country(
    val name: String,
    val flagEmoji: String,
    val dialCode: String, // digits only, no leading "+"
) {
    val display: String get() = "$flagEmoji +$dialCode  $name"
    val dialCodeDisplay: String get() = "$flagEmoji +$dialCode"
}

/**
 * A curated (not exhaustive) list of common countries for the phone-number
 * country picker, Indonesia first since that's this app's primary market.
 */
object CountryCodes {

    val ALL: List<Country> = listOf(
        Country("Indonesia", "\uD83C\uDDEE\uD83C\uDDE9", "62"),
        Country("Malaysia", "\uD83C\uDDF2\uD83C\uDDFE", "60"),
        Country("Singapura", "\uD83C\uDDF8\uD83C\uDDEC", "65"),
        Country("Thailand", "\uD83C\uDDF9\uD83C\uDDED", "66"),
        Country("Filipina", "\uD83C\uDDF5\uD83C\uDDED", "63"),
        Country("Vietnam", "\uD83C\uDDFB\uD83C\uDDF3", "84"),
        Country("Brunei", "\uD83C\uDDE7\uD83C\uDDF3", "673"),
        Country("Kamboja", "\uD83C\uDDF0\uD83C\uDDED", "855"),
        Country("Myanmar", "\uD83C\uDDF2\uD83C\uDDF2", "95"),
        Country("Laos", "\uD83C\uDDF1\uD83C\uDDE6", "856"),
        Country("India", "\uD83C\uDDEE\uD83C\uDDF3", "91"),
        Country("Pakistan", "\uD83C\uDDF5\uD83C\uDDF0", "92"),
        Country("Bangladesh", "\uD83C\uDDE7\uD83C\uDDE9", "880"),
        Country("Sri Lanka", "\uD83C\uDDF1\uD83C\uDDF0", "94"),
        Country("Nepal", "\uD83C\uDDF3\uD83C\uDDF5", "977"),
        Country("China", "\uD83C\uDDE8\uD83C\uDDF3", "86"),
        Country("Hong Kong", "\uD83C\uDDED\uD83C\uDDF0", "852"),
        Country("Taiwan", "\uD83C\uDDF9\uD83C\uDDFC", "886"),
        Country("Jepang", "\uD83C\uDDEF\uD83C\uDDF5", "81"),
        Country("Korea Selatan", "\uD83C\uDDF0\uD83C\uDDF7", "82"),
        Country("Arab Saudi", "\uD83C\uDDF8\uD83C\uDDE6", "966"),
        Country("Uni Emirat Arab", "\uD83C\uDDE6\uD83C\uDDEA", "971"),
        Country("Qatar", "\uD83C\uDDF6\uD83C\uDDE6", "974"),
        Country("Kuwait", "\uD83C\uDDF0\uD83C\uDDFC", "965"),
        Country("Turki", "\uD83C\uDDF9\uD83C\uDDF7", "90"),
        Country("Mesir", "\uD83C\uDDEA\uD83C\uDDEC", "20"),
        Country("Australia", "\uD83C\uDDE6\uD83C\uDDFA", "61"),
        Country("Selandia Baru", "\uD83C\uDDF3\uD83C\uDDFF", "64"),
        Country("Amerika Serikat / Kanada", "\uD83C\uDDFA\uD83C\uDDF8", "1"),
        Country("Inggris Raya", "\uD83C\uDDEC\uD83C\uDDE7", "44"),
        Country("Irlandia", "\uD83C\uDDEE\uD83C\uDDEA", "353"),
        Country("Jerman", "\uD83C\uDDE9\uD83C\uDDEA", "49"),
        Country("Prancis", "\uD83C\uDDEB\uD83C\uDDF7", "33"),
        Country("Belanda", "\uD83C\uDDF3\uD83C\uDDF1", "31"),
        Country("Belgia", "\uD83C\uDDE7\uD83C\uDDEA", "32"),
        Country("Spanyol", "\uD83C\uDDEA\uD83C\uDDF8", "34"),
        Country("Portugal", "\uD83C\uDDF5\uD83C\uDDF9", "351"),
        Country("Italia", "\uD83C\uDDEE\uD83C\uDDF9", "39"),
        Country("Swiss", "\uD83C\uDDE8\uD83C\uDDED", "41"),
        Country("Swedia", "\uD83C\uDDF8\uD83C\uDDEA", "46"),
        Country("Rusia", "\uD83C\uDDF7\uD83C\uDDFA", "7"),
        Country("Brasil", "\uD83C\uDDE7\uD83C\uDDF7", "55"),
        Country("Meksiko", "\uD83C\uDDF2\uD83C\uDDFD", "52"),
        Country("Afrika Selatan", "\uD83C\uDDFF\uD83C\uDDE6", "27"),
        Country("Nigeria", "\uD83C\uDDF3\uD83C\uDDEC", "234"),
    )

    val DEFAULT: Country = ALL.first() // Indonesia

    fun byDialCode(dialCode: String): Country? = ALL.firstOrNull { it.dialCode == dialCode }
}
