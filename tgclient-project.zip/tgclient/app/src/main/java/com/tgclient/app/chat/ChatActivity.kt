package com.tgclient.app.chat

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.R
import com.tgclient.app.profile.ProfileActivity
import com.tgclient.app.report.ReportDialog
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession
import com.tgclient.app.util.AvatarLoader
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

class ChatActivity : AppCompatActivity() {

    private lateinit var session: TdlibSession
    private lateinit var adapter: MessageAdapter
    private var accountId: String = ""
    private var chatId: Long = 0L
    private var otherUserId: Long = 0L
    private var chatType: TdApi.ChatType? = null

    // ViewModel keeps ChatRepository (and its loaded history) alive across
    // rotation instead of reloading it from scratch every time.
    private val viewModel: ChatViewModel by viewModels {
        ChatViewModel.Factory(
            intent.getStringExtra(EXTRA_ACCOUNT_ID) ?: "",
            intent.getLongExtra(EXTRA_CHAT_ID, 0L),
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID) ?: ""
        chatId = intent.getLongExtra(EXTRA_CHAT_ID, 0L)
        val chatTitle = intent.getStringExtra(EXTRA_CHAT_TITLE) ?: ""

        session = AccountManager.getSession(accountId)
            ?: AccountManager.getActiveSession()
            ?: run { finish(); return }

        val repository = viewModel.repository
        if (repository == null) {
            finish()
            return
        }

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val toolbarAvatarInitial = findViewById<TextView>(R.id.toolbarAvatarInitial)
        val toolbarAvatarPhoto = findViewById<ImageView>(R.id.toolbarAvatarPhoto)
        val toolbarTitle = findViewById<TextView>(R.id.toolbarChatTitle)
        val toolbarSubtitle = findViewById<TextView>(R.id.toolbarChatSubtitle)
        toolbarTitle.text = chatTitle
        toolbarAvatarInitial.text = (chatTitle.firstOrNull() ?: '?').toString().uppercase()
        findViewById<View>(R.id.chatToolbarContent).setOnClickListener {
            if (chatType is TdApi.ChatTypePrivate) {
                if (otherUserId != 0L) {
                    ProfileActivity.startForUser(this, accountId, otherUserId, chatId)
                }
            } else if (chatType != null) {
                GroupPhotoDialog(this, session, chatId).show()
            }
        }

        val loadingIndicator = findViewById<ProgressBar>(R.id.chatLoadingIndicator)
        val recycler = findViewById<RecyclerView>(R.id.messageRecycler)
        adapter = MessageAdapter { message ->
            MessageActionsDialog.show(this, session, chatId, message.messageId, message.text)
        }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        lifecycleScope.launch {
            repository.isLoading.collect { loading ->
                loadingIndicator.visibility = if (loading) View.VISIBLE else View.GONE
            }
        }

        lifecycleScope.launch {
            repository.messages.collect { messages ->
                val wasAtBottom = !recycler.canScrollVertically(1)
                adapter.submitList(messages) {
                    if (wasAtBottom && messages.isNotEmpty()) {
                        recycler.scrollToPosition(messages.size - 1)
                    }
                }
            }
        }

        lifecycleScope.launch {
            runCatching { session.send(TdApi.GetChat(chatId)) }
                .onSuccess { chat ->
                    chatType = chat.type
                    (chat.type as? TdApi.ChatTypePrivate)?.let { otherUserId = it.userId }
                    toolbarSubtitle.text = subtitleFor(chat.type)

                    val bitmap = AvatarLoader.loadSmall(session, chat.photo)
                    if (bitmap != null) {
                        toolbarAvatarPhoto.setImageBitmap(bitmap)
                        toolbarAvatarPhoto.visibility = View.VISIBLE
                    }
                }
        }

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        sendButton.setOnClickListener {
            val text = input.text.toString()
            if (text.isBlank()) return@setOnClickListener
            input.setText("")
            lifecycleScope.launch {
                runCatching { repository.sendText(text) }
            }
        }
    }

    private suspend fun subtitleFor(type: TdApi.ChatType?): String {
        return when (type) {
            is TdApi.ChatTypePrivate -> {
                val user = runCatching { session.send(TdApi.GetUser(type.userId)) }.getOrNull()
                when (user?.status) {
                    is TdApi.UserStatusOnline -> getString(R.string.status_online)
                    else -> getString(R.string.status_offline)
                }
            }
            is TdApi.ChatTypeBasicGroup -> {
                val group = runCatching { session.send(TdApi.GetBasicGroup(type.basicGroupId)) }.getOrNull()
                resources.getQuantityString(
                    R.plurals.member_count,
                    group?.memberCount ?: 0,
                    group?.memberCount ?: 0,
                )
            }
            is TdApi.ChatTypeSupergroup -> {
                val full = runCatching { session.send(TdApi.GetSupergroupFullInfo(type.supergroupId)) }.getOrNull()
                val countRes = if (type.isChannel) R.plurals.subscriber_count else R.plurals.member_count
                resources.getQuantityString(countRes, full?.memberCount ?: 0, full?.memberCount ?: 0)
            }
            else -> ""
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_chat, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_view_profile -> {
                if (otherUserId != 0L) {
                    ProfileActivity.startForUser(this, accountId, otherUserId, chatId)
                }
                true
            }
            R.id.action_report_chat -> {
                ReportDialog(this, session, chatId).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        private const val EXTRA_ACCOUNT_ID = "account_id"
        private const val EXTRA_CHAT_ID = "chat_id"
        private const val EXTRA_CHAT_TITLE = "chat_title"

        fun start(context: Context, accountId: String, chatId: Long, chatTitle: String) {
            context.startActivity(
                Intent(context, ChatActivity::class.java)
                    .putExtra(EXTRA_ACCOUNT_ID, accountId)
                    .putExtra(EXTRA_CHAT_ID, chatId)
                    .putExtra(EXTRA_CHAT_TITLE, chatTitle),
            )
        }
    }
}
