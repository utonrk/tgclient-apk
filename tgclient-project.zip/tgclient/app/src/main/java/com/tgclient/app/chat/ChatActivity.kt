package com.tgclient.app.chat

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.R
import com.tgclient.app.profile.ProfileActivity
import com.tgclient.app.report.ReportDialog
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.ChatRepository
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

class ChatActivity : AppCompatActivity() {

    private lateinit var session: TdlibSession
    private lateinit var repository: ChatRepository
    private lateinit var adapter: MessageAdapter
    private var accountId: String = ""
    private var chatId: Long = 0L
    private var otherUserId: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        accountId = intent.getStringExtra(EXTRA_ACCOUNT_ID) ?: ""
        chatId = intent.getLongExtra(EXTRA_CHAT_ID, 0L)
        val chatTitle = intent.getStringExtra(EXTRA_CHAT_TITLE) ?: ""

        session = AccountManager.getSession(accountId)
            ?: AccountManager.getActiveSession()
            ?: run { finish(); return }

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = chatTitle
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val recycler = findViewById<RecyclerView>(R.id.messageRecycler)
        adapter = MessageAdapter { messageId, text ->
            com.tgclient.app.chat.MessageActionsDialog.show(this, session, chatId, messageId, text)
        }
        val layoutManager = LinearLayoutManager(this)
        recycler.layoutManager = layoutManager
        recycler.adapter = adapter

        repository = ChatRepository(session, chatId, lifecycleScope)
        repository.start()

        lifecycleScope.launch {
            repository.messages.collect { messages ->
                adapter.submitList(messages)
                if (messages.isNotEmpty()) recycler.scrollToPosition(messages.size - 1)
            }
        }

        lifecycleScope.launch {
            runCatching { session.send(TdApi.GetChat(chatId)) }
                .onSuccess { chat ->
                    (chat.type as? TdApi.ChatTypePrivate)?.let { otherUserId = it.userId }
                }
        }

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<Button>(R.id.sendButton)
        sendButton.setOnClickListener {
            val text = input.text.toString()
            if (text.isBlank()) return@setOnClickListener
            input.setText("")
            lifecycleScope.launch {
                runCatching { repository.sendText(text) }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_chat, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_view_profile -> {
                if (otherUserId != 0L) {
                    ProfileActivity.startForUser(this, accountId, otherUserId, chatId)
                }
                true
            }
            R.id.action_report_chat -> {
                ReportDialog(this, session, chatId).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        repository.stop()
        super.onDestroy()
    }

    companion object {
        private const val EXTRA_ACCOUNT_ID = "account_id"
        private const val EXTRA_CHAT_ID = "chat_id"
        private const val EXTRA_CHAT_TITLE = "chat_title"

        fun start(context: Context, accountId: String, chatId: Long, chatTitle: String) {
            context.startActivity(
                Intent(context, ChatActivity::class.java)
                    .putExtra(EXTRA_ACCOUNT_ID, accountId)
                    .putExtra(EXTRA_CHAT_ID, chatId)
                    .putExtra(EXTRA_CHAT_TITLE, chatTitle),
            )
        }
    }
}
