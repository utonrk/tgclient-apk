package com.tgclient.app.tdlib

import android.content.Context
import java.io.File
import java.util.UUID

/**
 * Owns every [TdlibSession] (= one Telegram account) that exists on this
 * device, keyed by a locally-generated account ID. Each account gets its
 * own directory under filesDir/tdlib-db/<accountId>/ so accounts never
 * share database/session state.
 *
 * This is a process-wide singleton because TDLib clients are meant to be
 * long-lived — they should be created once and reused, not recreated per
 * screen/activity.
 */
object AccountManager {

    private lateinit var appContext: Context
    private lateinit var store: AccountStore
    private val sessions = mutableMapOf<String, TdlibSession>()
    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        appContext = context.applicationContext
        store = AccountStore(appContext)
        initialized = true

        // Re-create a session (and resume its TDLib client) for every
        // account that was already logged in / mid-login before the
        // process died.
        store.getAccountIds().forEach { accountId ->
            getOrCreateSession(accountId)
        }
    }

    fun listAccountIds(): List<String> = store.getAccountIds()

    fun getActiveAccountId(): String? = store.getActiveAccountId()

    fun setActiveAccountId(accountId: String) {
        require(store.getAccountIds().contains(accountId)) {
            "Unknown accountId: $accountId"
        }
        store.setActiveAccountId(accountId)
    }

    fun getActiveSession(): TdlibSession? {
        val id = store.getActiveAccountId() ?: return null
        return sessions[id]
    }

    fun getSession(accountId: String): TdlibSession? = sessions[accountId]

    /**
     * Starts the login flow for a brand-new account and makes it the
     * active account. Returns the new session so the caller (login
     * screen) can observe its [TdlibSession.authState].
     */
    fun addAccount(): TdlibSession {
        val accountId = UUID.randomUUID().toString()
        store.addAccountId(accountId)
        store.setActiveAccountId(accountId)
        return getOrCreateSession(accountId)
    }

    fun removeAccount(accountId: String) {
        sessions.remove(accountId)?.close()
        store.removeAccountId(accountId)
        accountDirectory(accountId).deleteRecursively()
    }

    private fun getOrCreateSession(accountId: String): TdlibSession {
        sessions[accountId]?.let { return it }

        val baseDir = accountDirectory(accountId)
        val databaseDir = File(baseDir, "database").apply { mkdirs() }
        val filesDir = File(baseDir, "files").apply { mkdirs() }

        val session = TdlibSession(
            accountId = accountId,
            databaseDirectory = databaseDir.absolutePath,
            filesDirectory = filesDir.absolutePath,
        )
        sessions[accountId] = session
        return session
    }

    private fun accountDirectory(accountId: String): File =
        File(appContext.filesDir, "tdlib-db/$accountId")
}
