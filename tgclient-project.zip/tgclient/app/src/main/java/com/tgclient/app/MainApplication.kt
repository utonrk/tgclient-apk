package com.tgclient.app

import android.app.Application
import com.tgclient.app.tdlib.AccountManager

class MainApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        // AccountManager needs a Context to know where to store each
        // account's TDLib database (filesDir/tdlib-db/<accountId>/).
        AccountManager.init(applicationContext)
    }
}
