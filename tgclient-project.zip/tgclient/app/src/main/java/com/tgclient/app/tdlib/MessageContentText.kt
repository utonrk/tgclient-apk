package com.tgclient.app.tdlib

import org.drinkless.tdlib.TdApi

/**
 * Turns raw TDLib message content into a short display string. Used by
 * both [ChatListRepository] (last-message preview) and [ChatRepository]
 * (message bubble text) so the two don't drift out of sync — this used to
 * be two near-identical copies of the same `when` block.
 */
object MessageContentText {

    fun of(content: TdApi.MessageContent?): String {
        content ?: return ""
        return when (content) {
            is TdApi.MessageText -> content.text.text
            is TdApi.MessagePhoto ->
                "\uD83D\uDCF7 Foto" + (content.caption?.text?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "")
            is TdApi.MessageVideo -> "\uD83C\uDFA5 Video"
            is TdApi.MessageDocument -> "\uD83D\uDCC4 " + (content.document?.fileName ?: "Dokumen")
            is TdApi.MessageSticker -> "${content.sticker?.emoji ?: "\uD83C\uDFB4"} Stiker"
            is TdApi.MessageVoiceNote -> "\uD83C\uDFA4 Pesan suara"
            is TdApi.MessageVideoNote -> "\uD83D\uDCF9 Pesan video"
            is TdApi.MessageAnimation ->
                "\uD83C\uDFAC GIF" + (content.caption?.text?.takeIf { it.isNotBlank() }?.let { ": $it" } ?: "")
            is TdApi.MessageAnimatedEmoji -> content.animatedEmoji?.sticker?.emoji ?: "\uD83C\uDFB4"
            is TdApi.MessageAudio -> "\uD83C\uDFB5 " + (content.audio?.fileName ?: "Audio")
            is TdApi.MessageLocation -> "\uD83D\uDCCD Lokasi"
            is TdApi.MessageContact -> "\uD83D\uDC64 Kontak"
            is TdApi.MessagePoll -> "\uD83D\uDCCA " + (content.poll?.question?.text ?: "Polling")
            is TdApi.MessageCall -> "\uD83D\uDCDE Panggilan"
            is TdApi.MessageChatDeleteMember -> "anggota keluar dari grup"
            is TdApi.MessageChatAddMembers -> "anggota ditambahkan ke grup"
            else -> "[pesan]"
        }
    }
}
