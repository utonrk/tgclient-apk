package com.tgclient.app.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputLayout
import com.tgclient.app.MainActivity
import com.tgclient.app.R
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var session: TdlibSession

    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar

    private lateinit var phoneGroup: View
    private lateinit var countryInput: AutoCompleteTextView
    private lateinit var phoneNumberLayout: TextInputLayout
    private lateinit var phoneInput: EditText
    private lateinit var phoneButton: Button

    private lateinit var codeGroup: View
    private lateinit var codeInput: EditText
    private lateinit var codeButton: Button

    private lateinit var passwordGroup: View
    private lateinit var passwordInput: EditText
    private lateinit var passwordButton: Button

    private var selectedCountry: Country = CountryCodes.DEFAULT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val forceNewAccount = intent.getBooleanExtra(EXTRA_FORCE_NEW_ACCOUNT, false)

        // If an account is already fully logged in, skip straight past login
        // — unless we were explicitly asked to add another one.
        val active = AccountManager.getActiveSession()
        if (!forceNewAccount && active != null && active.authState.value is TdlibSession.AuthState.Ready) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_login)
        session = if (forceNewAccount) {
            AccountManager.addAccount()
        } else {
            active ?: AccountManager.addAccount()
        }

        bindViews()
        setUpCountryPicker()
        bindActions()
        observeAuthState()
    }

    private fun bindViews() {
        statusText = findViewById(R.id.statusText)
        progressBar = findViewById(R.id.progressBar)

        phoneGroup = findViewById(R.id.phoneGroup)
        countryInput = findViewById(R.id.countryInput)
        phoneNumberLayout = findViewById(R.id.phoneNumberLayout)
        phoneInput = findViewById(R.id.phoneInput)
        phoneButton = findViewById(R.id.phoneButton)

        codeGroup = findViewById(R.id.codeGroup)
        codeInput = findViewById(R.id.codeInput)
        codeButton = findViewById(R.id.codeButton)

        passwordGroup = findViewById(R.id.passwordGroup)
        passwordInput = findViewById(R.id.passwordInput)
        passwordButton = findViewById(R.id.passwordButton)
    }

    private fun setUpCountryPicker() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, CountryCodes.ALL.map { it.display })
        countryInput.setAdapter(adapter)
        countryInput.setText(selectedCountry.display, false)
        countryInput.setOnItemClickListener { _, _, position, _ ->
            selectedCountry = CountryCodes.ALL[position]
            phoneNumberLayout.error = null
        }

        // Clear any leftover validation error as soon as the user edits the number again.
        phoneInput.addTextChangedListener(onTextChanged = { _, _, _, _ -> phoneNumberLayout.error = null })
    }

    private fun bindActions() {
        phoneButton.setOnClickListener {
            val nationalNumber = PhoneNumberValidator.sanitizeNationalNumber(phoneInput.text.toString())
            when (PhoneNumberValidator.validate(selectedCountry.dialCode, nationalNumber)) {
                PhoneNumberValidator.Result.Empty -> {
                    phoneNumberLayout.error = getString(R.string.error_phone_empty)
                    return@setOnClickListener
                }
                PhoneNumberValidator.Result.TooShort -> {
                    phoneNumberLayout.error = getString(R.string.error_phone_too_short)
                    return@setOnClickListener
                }
                PhoneNumberValidator.Result.TooLong -> {
                    phoneNumberLayout.error = getString(R.string.error_phone_too_long)
                    return@setOnClickListener
                }
                PhoneNumberValidator.Result.Valid -> phoneNumberLayout.error = null
            }

            val fullPhoneNumber = selectedCountry.dialCode + nationalNumber
            lifecycleScope.launch {
                runCatching { session.submitPhoneNumber(fullPhoneNumber) }
                    .onFailure { showError(it) }
            }
        }

        codeButton.setOnClickListener {
            val code = codeInput.text.toString().trim()
            if (code.isEmpty()) {
                statusText.text = getString(R.string.status_waiting_code)
                return@setOnClickListener
            }
            lifecycleScope.launch {
                runCatching { session.submitCode(code) }
                    .onFailure { showError(it) }
            }
        }

        passwordButton.setOnClickListener {
            val password = passwordInput.text.toString()
            lifecycleScope.launch {
                runCatching { session.submitPassword(password) }
                    .onFailure { showError(it) }
            }
        }
    }

    private fun observeAuthState() {
        lifecycleScope.launch {
            session.authState.collect { state ->
                render(state)
                if (state is TdlibSession.AuthState.Ready) {
                    goToMain()
                }
            }
        }
    }

    private fun render(state: TdlibSession.AuthState) {
        phoneGroup.visibility = View.GONE
        codeGroup.visibility = View.GONE
        passwordGroup.visibility = View.GONE
        progressBar.visibility = View.GONE

        when (state) {
            is TdlibSession.AuthState.Uninitialized -> {
                statusText.text = getString(R.string.status_waiting_phone)
                progressBar.visibility = View.VISIBLE
            }
            is TdlibSession.AuthState.WaitPhoneNumber -> {
                statusText.text = getString(R.string.status_waiting_phone)
                phoneGroup.visibility = View.VISIBLE
            }
            is TdlibSession.AuthState.WaitCode -> {
                statusText.text = getString(R.string.status_waiting_code)
                codeGroup.visibility = View.VISIBLE
            }
            is TdlibSession.AuthState.WaitPassword -> {
                statusText.text = getString(R.string.status_waiting_password)
                passwordGroup.visibility = View.VISIBLE
            }
            is TdlibSession.AuthState.LoggingIn -> {
                statusText.text = getString(R.string.status_logging_in)
                progressBar.visibility = View.VISIBLE
            }
            is TdlibSession.AuthState.Ready -> {
                statusText.text = getString(R.string.status_ready)
            }
            is TdlibSession.AuthState.LoggedOut -> {
                statusText.text = getString(R.string.status_waiting_phone)
                phoneGroup.visibility = View.VISIBLE
            }
            is TdlibSession.AuthState.Error -> {
                statusText.text = getString(R.string.status_error, state.message)
                phoneGroup.visibility = View.VISIBLE
            }
        }
    }

    private fun showError(t: Throwable) {
        statusText.text = getString(R.string.status_error, t.message ?: t.toString())
    }

    private fun goToMain() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
        finish()
    }

    companion object {
        /** Boolean extra: when true, always start a fresh login even if an account is already active. */
        const val EXTRA_FORCE_NEW_ACCOUNT = "force_new_account"
    }
}
