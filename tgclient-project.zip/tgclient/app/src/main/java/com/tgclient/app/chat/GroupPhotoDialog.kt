package com.tgclient.app.chat

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.tgclient.app.R
import com.tgclient.app.tdlib.TdlibSession
import com.tgclient.app.util.AvatarLoader
import com.tgclient.app.util.activityScopeOrNull
import kotlinx.coroutines.launch
import org.drinkless.tdlib.TdApi

/**
 * "Foto profil" dialog for a group or channel chat — tapping the avatar in
 * [ChatActivity]'s toolbar opens this instead of the (user-only)
 * ProfileActivity. Shows the big avatar photo, a member/subscriber count
 * subtitle, and the group's description if it has one.
 */
class GroupPhotoDialog(
    private val context: Context,
    private val session: TdlibSession,
    private val chatId: Long,
) {

    fun show() {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_group_photo, null)
        val initial = view.findViewById<TextView>(R.id.groupPhotoInitial)
        val photo = view.findViewById<ImageView>(R.id.groupPhotoImage)
        val loading = view.findViewById<ProgressBar>(R.id.groupPhotoLoading)
        val titleView = view.findViewById<TextView>(R.id.groupPhotoTitle)
        val subtitleView = view.findViewById<TextView>(R.id.groupPhotoSubtitle)
        val descriptionView = view.findViewById<TextView>(R.id.groupPhotoDescription)

        val dialog = AlertDialog.Builder(context)
            .setView(view)
            .setPositiveButton(R.string.action_close, null)
            .create()
        dialog.show()

        val scope = context.activityScopeOrNull ?: return
        scope.launch {
            val chat = runCatching { session.send(TdApi.GetChat(chatId)) }.getOrNull()
            if (chat == null) {
                dialog.dismiss()
                return@launch
            }

            titleView.text = chat.title.ifBlank { context.getString(R.string.title_group_default) }
            initial.text = (chat.title.firstOrNull() ?: '?').toString().uppercase()

            loadInfo(chat.type, subtitleView, descriptionView)

            val bitmap = AvatarLoader.loadBig(session, chat.photo)
            loading.visibility = View.GONE
            if (bitmap != null) {
                photo.setImageBitmap(bitmap)
                photo.visibility = View.VISIBLE
            }
        }
    }

    private suspend fun loadInfo(type: TdApi.ChatType?, subtitleView: TextView, descriptionView: TextView) {
        when (type) {
            is TdApi.ChatTypeBasicGroup -> {
                val group = runCatching { session.send(TdApi.GetBasicGroup(type.basicGroupId)) }.getOrNull()
                subtitleView.text = context.resources.getQuantityString(
                    R.plurals.member_count,
                    group?.memberCount ?: 0,
                    group?.memberCount ?: 0,
                )
                val full = runCatching { session.send(TdApi.GetBasicGroupFullInfo(type.basicGroupId)) }.getOrNull()
                showDescription(full?.description, descriptionView)
            }
            is TdApi.ChatTypeSupergroup -> {
                val full = runCatching { session.send(TdApi.GetSupergroupFullInfo(type.supergroupId)) }.getOrNull()
                val countRes = if (type.isChannel) R.plurals.subscriber_count else R.plurals.member_count
                subtitleView.text = context.resources.getQuantityString(
                    countRes,
                    full?.memberCount ?: 0,
                    full?.memberCount ?: 0,
                )
                showDescription(full?.description, descriptionView)
            }
            else -> {
                subtitleView.visibility = View.GONE
            }
        }
    }

    private fun showDescription(description: String?, descriptionView: TextView) {
        if (!description.isNullOrBlank()) {
            descriptionView.text = description
            descriptionView.visibility = View.VISIBLE
        }
    }
}
