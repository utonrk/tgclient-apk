package com.tgclient.app.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.R
import com.tgclient.app.tdlib.MessageItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MessageAdapter(
    private val onLongClick: (MessageItem) -> Unit,
) : ListAdapter<MessageItem, MessageAdapter.ViewHolder>(DIFF_CALLBACK) {

    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.messageText)
        val time: TextView = view.findViewById(R.id.messageTime)
    }

    override fun getItemViewType(position: Int): Int =
        if (getItem(position).isOutgoing) VIEW_TYPE_OUT else VIEW_TYPE_IN

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layout = if (viewType == VIEW_TYPE_OUT) R.layout.item_message_out else R.layout.item_message_in
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = getItem(position)
        holder.text.text = item.text
        holder.time.text = if (item.dateSeconds > 0) {
            timeFormat.format(Date(item.dateSeconds.toLong() * 1000L))
        } else {
            ""
        }
        holder.itemView.setOnLongClickListener {
            onLongClick(item)
            true
        }
    }

    companion object {
        private const val VIEW_TYPE_IN = 0
        private const val VIEW_TYPE_OUT = 1

        // MessageItem is a data class, so equals() already compares every
        // field for us.
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<MessageItem>() {
            override fun areItemsTheSame(oldItem: MessageItem, newItem: MessageItem) =
                oldItem.messageId == newItem.messageId

            override fun areContentsTheSame(oldItem: MessageItem, newItem: MessageItem) =
                oldItem == newItem
        }
    }
}
