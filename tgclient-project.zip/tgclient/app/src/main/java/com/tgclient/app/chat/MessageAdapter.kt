package com.tgclient.app.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.R
import com.tgclient.app.tdlib.MessageItem

class MessageAdapter : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {

    private var items: List<MessageItem> = emptyList()

    fun submitList(newItems: List<MessageItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.messageText)
    }

    override fun getItemViewType(position: Int): Int =
        if (items[position].isOutgoing) VIEW_TYPE_OUT else VIEW_TYPE_IN

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val layout = if (viewType == VIEW_TYPE_OUT) R.layout.item_message_out else R.layout.item_message_in
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.text.text = items[position].text
    }

    override fun getItemCount(): Int = items.size

    companion object {
        private const val VIEW_TYPE_IN = 0
        private const val VIEW_TYPE_OUT = 1
    }
}
