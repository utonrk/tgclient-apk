package com.tgclient.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tgclient.app.tdlib.AccountManager
import kotlinx.coroutines.launch

/**
 * Placeholder post-login screen. This is where the chat list (phase 2),
 * chat screen (phase 3), profile (phase 4), and report flow (phase 5)
 * will be wired in, per the project prompt's build order.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val label = TextView(this).apply {
            textSize = 18f
            setPadding(32, 64, 32, 32)
        }
        setContentView(label)

        val session = AccountManager.getActiveSession()
        if (session == null) {
            label.text = "Tidak ada akun aktif."
            return
        }

        lifecycleScope.launch {
            session.profile.collect { profile ->
                label.text = buildString {
                    append("Berhasil login sebagai:\n\n")
                    append("${profile.firstName} ${profile.lastName}".trim())
                    if (profile.username.isNotBlank()) append("\n@${profile.username}")
                    if (profile.phoneNumber.isNotBlank()) append("\n+${profile.phoneNumber}")
                    append("\n\n(Daftar chat, kirim pesan, profil, dan report akan ditambahkan di fase berikutnya.)")
                }
            }
        }
    }
}
