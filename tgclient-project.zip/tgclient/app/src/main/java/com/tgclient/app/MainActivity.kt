package com.tgclient.app

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.account.AccountSwitcherDialog
import com.tgclient.app.chat.ChatActivity
import com.tgclient.app.chatlist.ChatListAdapter
import com.tgclient.app.profile.ProfileActivity
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.ChatListRepository
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch

/**
 * Post-login home screen: chat list for the active account, plus a toolbar
 * menu to switch/add accounts and open the signed-in user's own profile.
 */
class MainActivity : AppCompatActivity() {

    private var session: TdlibSession? = null
    private var repository: ChatListRepository? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.title = getString(R.string.app_name)

        val emptyText = findViewById<TextView>(R.id.emptyText)
        val recycler = findViewById<RecyclerView>(R.id.chatListRecycler)
        recycler.layoutManager = LinearLayoutManager(this)

        val activeSession = AccountManager.getActiveSession()
        session = activeSession
        if (activeSession == null) {
            emptyText.visibility = android.view.View.VISIBLE
            emptyText.text = getString(R.string.status_no_active_account)
            return
        }

        val adapter = ChatListAdapter { item ->
            ChatActivity.start(this, activeSession.accountId, item.chatId, item.title)
        }
        recycler.adapter = adapter

        val repo = ChatListRepository(activeSession, lifecycleScope)
        repository = repo
        repo.start()

        lifecycleScope.launch {
            repo.chatList.collect { chats ->
                adapter.submitList(chats)
                emptyText.visibility = if (chats.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
                if (chats.isEmpty()) emptyText.text = getString(R.string.chat_list_empty)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_switch_account -> {
                AccountSwitcherDialog(this) { recreate() }.show()
                true
            }
            R.id.action_my_profile -> {
                session?.let { ProfileActivity.startForSelf(this, it.accountId) }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroy() {
        repository?.stop()
        super.onDestroy()
    }
}
