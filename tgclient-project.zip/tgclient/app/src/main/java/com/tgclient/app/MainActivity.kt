package com.tgclient.app

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tgclient.app.account.AccountSwitcherDialog
import com.tgclient.app.chat.ChatActivity
import com.tgclient.app.chatlist.ChatListAdapter
import com.tgclient.app.profile.ProfileActivity
import com.tgclient.app.tdlib.AccountManager
import com.tgclient.app.tdlib.TdlibSession
import kotlinx.coroutines.launch

/**
 * Post-login home screen: chat list for the active account, plus a toolbar
 * menu to switch/add accounts and open the signed-in user's own profile.
 *
 * The chat list itself lives in `session.chatListRepository` (owned by the
 * TdlibSession, not by this Activity) — so it survives rotation and stays
 * the same instance the forward-message picker reads from, instead of each
 * screen loading its own copy.
 */
class MainActivity : AppCompatActivity() {

    private var session: TdlibSession? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        toolbar.title = getString(R.string.app_name)

        val emptyText = findViewById<TextView>(R.id.emptyText)
        val loadingIndicator = findViewById<ProgressBar>(R.id.mainLoadingIndicator)
        val recycler = findViewById<RecyclerView>(R.id.chatListRecycler)
        recycler.layoutManager = LinearLayoutManager(this)

        val activeSession = AccountManager.getActiveSession()
        session = activeSession
        if (activeSession == null) {
            emptyText.visibility = View.VISIBLE
            emptyText.text = getString(R.string.status_no_active_account)
            return
        }

        val adapter = ChatListAdapter { item ->
            ChatActivity.start(this, activeSession.accountId, item.chatId, item.title)
        }
        recycler.adapter = adapter

        val repo = activeSession.chatListRepository

        lifecycleScope.launch {
            repo.isLoading.collect { loading ->
                loadingIndicator.visibility = if (loading) View.VISIBLE else View.GONE
            }
        }

        lifecycleScope.launch {
            repo.chatList.collect { chats ->
                adapter.submitList(chats)
                val stillLoading = repo.isLoading.value
                emptyText.visibility = if (chats.isEmpty() && !stillLoading) View.VISIBLE else View.GONE
                if (chats.isEmpty()) emptyText.text = getString(R.string.chat_list_empty)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_switch_account -> {
                AccountSwitcherDialog(this) { recreate() }.show()
                true
            }
            R.id.action_my_profile -> {
                session?.let { ProfileActivity.startForSelf(this, it.accountId) }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
