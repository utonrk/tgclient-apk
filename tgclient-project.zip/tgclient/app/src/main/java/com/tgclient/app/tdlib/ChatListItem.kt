package com.tgclient.app.tdlib

import org.drinkless.tdlib.TdApi

/** One row in the chat list screen. */
data class ChatListItem(
    val chatId: Long,
    val title: String,
    val lastMessagePreview: String,
    val lastMessageTimeSeconds: Int,
    val unreadCount: Int,
    val order: Long, // raw TDLib main-list position order, used for sorting only
    val photo: TdApi.ChatPhotoInfo? = null,
    val chatType: TdApi.ChatType? = null,
)
