package com.tgclient.app.tdlib

/** One row in the chat list screen. */
data class ChatListItem(
    val chatId: Long,
    val title: String,
    val lastMessagePreview: String,
    val lastMessageTimeSeconds: Int,
    val unreadCount: Int,
    val order: Long, // raw TDLib main-list position order, used for sorting only
)
