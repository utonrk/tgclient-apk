pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // TDLib binaries are NOT published on Maven Central.
        // You must either:
        //  (a) build TDLib from source with the Android NDK and drop the
        //      resulting .so files + org.drinkless.tdlib Java sources into
        //      app/src/main/{jniLibs,java}, or
        //  (b) obtain a prebuilt TDLib AAR from a source you trust and
        //      place it in app/libs/ (referenced below as a flatDir repo).
        flatDir {
            dirs("app/libs")
        }
    }
}

rootProject.name = "TgClient"
include(":app")
